import ast,datetime,hashlib,json,subprocess,sys
from pathlib import Path
from zipfile import ZipFile
root=Path.cwd();out=Path(sys.argv[1])
apk=out/'app.apk'
catalog=json.loads((out/'A.json').read_text())
release=catalog['latest'];assert (release['version'], release['versionCode']) in [('1.1.12',25),('1.1.13',26),('1.1.14',27),('1.1.15',28)]
sha=hashlib.sha256(apk.read_bytes()).hexdigest();assert sha==release['apkSha256'] and apk.stat().st_size==release['apkSizeBytes']
parser=root/'.release.local/verify-apk-1.1.3.py';tree=ast.parse(parser.read_text())
selected=[n for n in tree.body if isinstance(n,(ast.Import,ast.ImportFrom)) or isinstance(n,ast.FunctionDef) and n.name in ('u32','length8','length16','manifest_attributes')]
namespace={};exec(compile(ast.Module(body=selected,type_ignores=[]),str(parser),'exec'),namespace)
with ZipFile(apk) as z:
    loader=z.read('assets/public/index.html');expected=subprocess.check_output(['git','show','54a9df89f695a864a262f21c2706fc25510131da:.github/android/app-loader.html'])
    assert loader==expected and len(loader)<3000 and b'location.replace' in loader
    attrs=namespace['manifest_attributes'](z.read('AndroidManifest.xml'))
    assert attrs['versionName']==release['version'] and attrs['versionCode']==release['versionCode'] and attrs['package']=='com.inhousesoftware.read'
    public=sorted(n for n in z.namelist() if n.startswith('assets/public/') and not n.endswith('/'))
    assert public==['assets/public/cordova.js','assets/public/cordova_plugins.js','assets/public/index.html']
    (out/'loader.html').write_bytes(loader)
command=['C:/Program Files/Java/jdk-17/bin/java.exe','-cp','.release.local/apksig-8.9.0.jar;.release.local','VerifyReleaseSignature',str(apk)]
signature=subprocess.run(command,capture_output=True,text=True);(out/'apk-signature.log').write_text(signature.stdout+signature.stderr)
assert signature.returncode==0 and 'v2=true' in signature.stdout and '15a1f89c7a6fe7476bee6eaf48cc78239b5a5cb05f98daa4d3c02a6bc73284bd' in signature.stdout
summary=dict(status='passed',at=datetime.datetime.now(datetime.timezone.utc).isoformat(),release=release,bytes=apk.stat().st_size,sha256=sha,
    loaderBytes=len(loader),loaderSha256=hashlib.sha256(loader).hexdigest(),manifestAttributes=attrs,publicAssets=public,signatureVerified=True,
    limitation='Static download/signature/package/loader verification; No fresh physical-device session or real Google account was exercised; Live web integrity is checked separately.')
(out/'apk-summary.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary))
