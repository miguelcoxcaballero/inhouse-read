import {readFileSync,writeFileSync} from 'node:fs';
import assert from 'node:assert/strict';
const root='C:/Users/migue/Documents/InhouseRead-New',dir=process.argv[2];
const bytes=readFileSync(dir+'/core.wasm'),core=(await WebAssembly.instantiate(bytes)).instance.exports;
const mod=readFileSync(root+'/src/js/readers/neural-voice/speech-tempo.js','utf8').replace("import { getRustCore } from '../../rust-core.js'",'const getRustCore=()=>null');
const {rustSpeechTempo,speechTempoJS}=await import('data:text/javascript;base64,'+Buffer.from(mod).toString('base64'));
const results=[];
for(const sr of [8000,22050,24000,44100,48000,96000])for(const speed of [1,1.25,1.5,2,3]){
 const pcm=Float32Array.from({length:sr*2+71},(_,i)=>.6*Math.sin(i*.06)+.2*Math.sin(i*.019)),marks=[0,123,Math.floor(pcm.length/2),pcm.length-1];
 const expected=speechTempoJS(pcm,sr,speed,marks),actual=rustSpeechTempo(core,pcm,sr,speed,marks);
 assert.ok(actual);assert.ok(Buffer.from(expected.pcm.buffer).equals(Buffer.from(actual.pcm.buffer)));assert.deepEqual(actual.positions,expected.positions);
 results.push({sampleRate:sr,speed,samples:actual.pcm.length,marks:actual.positions});
}
writeFileSync(dir+'/tempo-kernel.json',JSON.stringify({status:'passed',scope:'Actual downloaded production WASM; complete PCM bytes and remapped markers match the reference',cases:results},null,2));console.log('30 published WASM speech tempo cases passed');
