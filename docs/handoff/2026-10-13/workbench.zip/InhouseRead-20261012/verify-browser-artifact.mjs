import {readFile,writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import assert from 'node:assert/strict';
import {chromium} from 'file:///C:/Users/migue/Documents/InhouseRead-New/node_modules/playwright/index.mjs';
const dir=process.argv[2],manifest=JSON.parse(await readFile(dir+'/summary.json','utf8'));
assert.deepEqual(manifest.errors,[]);const browser=await chromium.launch({headless:true}),results=[];
try{
 for(const device of [{name:'mobile',viewport:{width:390,height:844},deviceScaleFactor:2,isMobile:true,hasTouch:true},{name:'desktop',viewport:{width:1280,height:800},deviceScaleFactor:1}]){
  const {name,...options}=device,context=await browser.newContext(options),page=await context.newPage(),responses=[],errors=[];
  page.on('pageerror',error=>errors.push(error.message));
  const expected=[manifest.main,manifest.wasm,...(manifest.decor?[manifest.decor]:[])];
  page.on('response',response=>{const entry=expected.find(item=>response.url().endsWith('/'+item.path));if(entry)responses.push((async()=>{
   const body=await response.body(),sha256=createHash('sha256').update(body).digest('hex');
   assert.equal(response.status(),200);assert.equal(body.length,entry.bytes);assert.equal(sha256,entry.sha256);return{path:entry.path,bytes:body.length,sha256};
  })().catch(error=>{errors.push(error.stack);return{failed:true};}));});
  await page.goto('https://miguelcoxcaballero.github.io/inhouse-read/',{waitUntil:'domcontentloaded',timeout:45_000});
  await page.waitForFunction(paths=>paths.every(path=>performance.getEntriesByType('resource').some(entry=>entry.name.endsWith('/'+path))),expected.map(item=>item.path),{timeout:30_000});
  const loaded=await Promise.all(responses);for(const entry of expected)assert.ok(loaded.some(item=>item.path===entry.path));
  await page.screenshot({path:dir+'/browser-'+name+'.png'});results.push({device:name,loaded,pageErrors:errors,url:page.url()});assert.deepEqual(errors,[]);await context.close();
 }
}finally{await browser.close();await writeFile(dir+'/browser-artifact.json',JSON.stringify(results,null,2));}
console.log(JSON.stringify({source:manifest.source,profiles:results.length,exact:true}));
