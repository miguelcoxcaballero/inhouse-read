import zipfile,json,hashlib,sys
p=sys.argv[1]
with zipfile.ZipFile(p+'/app.apk') as z:
 names=[n for n in z.namelist() if n.startswith('assets/public/') and not n.endswith('/')]
 loader=z.read('assets/public/index.html')
 assert len(names)==3 and len(loader)==2107 and b'https://miguelcoxcaballero.github.io/inhouse-read/' in loader
 assert hashlib.sha256(loader).hexdigest()=='bc0fcb2fc3429759bb57f0d4f23dccc9137f938228b60400b1812be7cb7e1f6e'
 json.dump({'assets':names,'loaderBytes':len(loader),'sha256':hashlib.sha256(loader).hexdigest()},open(p+'/apk-loader.json','w'))
print('APK loader verified:',p)
