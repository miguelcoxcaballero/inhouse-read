import {readFile,writeFile} from 'node:fs/promises'
import {createHash} from 'node:crypto'
import assert from 'node:assert/strict'
import {chromium} from 'file:///C:/Users/migue/Documents/InhouseRead-New/node_modules/playwright/index.mjs'
const dir=process.argv[2],summary=JSON.parse(await readFile(dir+'/summary.json','utf8'))
assert.deepEqual(summary.errors,[])
const asset=summary.checks.find(entry=>/^assets\/inhouse_read_ui-[\w-]+\.js HTTP/.test(entry.label))?.label.split(' ')[0]
assert.ok(asset)
const base=process.env.IHR_TEST_URL||'https://miguelcoxcaballero.github.io/inhouse-read/'
const browser=await chromium.launch({headless:true}),proof=[]
try{
 for(const width of [390,1280]){
  const context=await browser.newContext({viewport:{width,height:844}}),page=await context.newPage(),loads=[],errors=[]
  await page.addInitScript(()=>{
   window.__uiInstances=0
   for(const name of ['instantiate','instantiateStreaming'])if(WebAssembly[name]){
    const original=WebAssembly[name]
    WebAssembly[name]=async function(...args){
     const result=await Reflect.apply(original,WebAssembly,args)
     if((result.instance||result).exports?.ui_live_handles)window.__uiInstances++
     return result
    }
   }
  })
  page.on('pageerror',e=>errors.push(e.message))
  page.on('response',response=>{if(response.url().endsWith('/'+summary.ui.path))loads.push((async()=>{
   const bytes=await response.body();assert.equal(response.status(),200);assert.equal(bytes.length,summary.ui.bytes)
   assert.equal(createHash('sha256').update(bytes).digest('hex'),summary.ui.sha256)
  })().catch(error=>{errors.push(error.stack)}))})
  await page.goto(base,{waitUntil:'domcontentloaded'})
  // Observe the app's own initialization before accessing its exported module.
  // Calling default() concurrently with the app can create a second instance
  // in wasm-bindgen before the first initialization has assigned its singleton.
  await page.waitForFunction(()=>window.__uiInstances>=1)
  const result=await page.evaluate(async url=>{
   const ui=await import(url);await ui.default()
   const prepare=async()=>{
    const source={physicalPage:1},next={clear(){},isValid(){return true}}
    const host={state:'playing',generation:1,index:0,chunks:['First.'],source,reader:{getNextSpeechSource:async()=>next},
     prepare:async value=>({source:value,items:[{text:'Next.'}]}),joinPageSentence(){},voiceFor:()=>({voice:null})}
    host.pagePlanValid=plan=>ui.voice_page_valid(plan);host.clearAhead=()=>ui.voice_clear_ahead(host)
    ui.voice_prepare_ahead(host,(owner,request)=>()=>ui.voice_ahead_active(owner,request),()=>null)
    await host.aheadPage.promise;host.clearAhead()
   }
   const menu=()=>{
    const menu=new ui.RustSelectMenu('Idioma',null,()=>{});menu.setOptions([{value:'es',label:'Español'},{value:'en',label:'English'}],'es')
    const root=menu.root;document.body.append(root);menu.open();menu.choose('en');menu.close({focus:false});root.remove();menu.free()
   }
   for(let i=0;i<10;i++){await prepare();menu()}
   const before=ui.ui_live_handles()
   const retained=new ui.RustSelectMenu('Lifetime control',null,()=>{})
   const duringRetention=ui.ui_live_handles();retained.free()
   const afterRelease=ui.ui_live_handles()
   if(!(duringRetention>before&&afterRelease===before))throw Error('Invalid lifetime counter')
   for(let i=0;i<1000;i++)await prepare()
   const afterPages=ui.ui_live_handles()
   for(let i=0;i<100;i++)menu()
   return {before,duringRetention,afterRelease,afterPages,afterMenus:ui.ui_live_handles(),pages:1000,menus:100,instances:window.__uiInstances,resources:performance.getEntriesByType('resource').filter(e=>e.name.includes('inhouse_read_ui')).map(e=>({name:e.name,initiator:e.initiatorType,transfer:e.transferSize}))}
  },new URL(asset,base).href)
  await Promise.all(loads);assert.ok(loads.length>0);assert.equal(result.instances,1);assert.deepEqual(errors,[])
  assert.equal(result.afterPages,result.before);assert.equal(result.afterMenus,result.before)
  proof.push({width,...result,wasm:summary.ui});await context.close()
 }
}finally{await browser.close();await writeFile(dir+'/ui-lifetime.json',JSON.stringify(proof,null,2))}
console.log(JSON.stringify({profiles:proof.length,stable:true,proof}))
