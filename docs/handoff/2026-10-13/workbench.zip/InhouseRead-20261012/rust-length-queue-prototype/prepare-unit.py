from pathlib import Path
root=Path('C:/Users/migue/Documents/InhouseRead-New');out=Path(__file__).parent
s=(root/'tests/unit/book-length-queue.test.js').read_text(encoding='utf8')
s=s.replace('afterEach, beforeEach,','afterEach, beforeEach, beforeAll,')
s=s.replace("import { createBookLengthQueue, isBookLengthReady } from '../../src/js/book-length-queue.js';", "import {isBookLengthReady,newContentRevision} from '../../src/js/book-length-queue.js';")
s=s.replace("import { completeWordCount }", "import { completeWordCount,hasCompleteWordCount }")
prefix=f'''import {{readFileSync}} from 'node:fs';
import * as ui from '{(out/'pkg/inhouse_read_ui.js').as_posix()}';
import {{createNativeLengthQueue}} from '{(out/'factory.mjs').as_posix()}';
beforeAll(()=>ui.initSync({{module:readFileSync('{(out/'pkg/inhouse_read_ui_bg.wasm').as_posix()}')}}));
function createBookLengthQueue(library,options){{return createNativeLengthQueue(library,options,ui,{{ready:isBookLengthReady,hasComplete:hasCompleteWordCount,complete:completeWordCount,revision:newContentRevision}})}}
afterEach(()=>expect(ui.ui_live_handles()).toBe(0));
'''
(root/'tests/unit/book-length-queue-rust-prototype.test.js').write_bytes((prefix+s).encode('utf8'))
