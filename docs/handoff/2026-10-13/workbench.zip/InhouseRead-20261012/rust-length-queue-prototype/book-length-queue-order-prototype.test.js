import {beforeAll,afterEach,it,expect,vi} from 'vitest'
import {readFileSync} from 'node:fs'
import * as ui from 'D:/CodexEvidence/InhouseRead-20261012/rust-length-queue-prototype/pkg/inhouse_read_ui.js'
import {createNativeLengthQueue} from 'D:/CodexEvidence/InhouseRead-20261012/rust-length-queue-prototype/factory.mjs'
import {createBookLengthQueue,isBookLengthReady,newContentRevision} from '../../src/js/book-length-queue.js'
import {hasCompleteWordCount,completeWordCount} from '../../src/js/book-length.js'
const helpers={ready:isBookLengthReady,revision:newContentRevision,hasComplete:hasCompleteWordCount,complete:completeWordCount}
const queues=[]
beforeAll(()=>{ui.initSync({module:readFileSync('D:/CodexEvidence/InhouseRead-20261012/rust-length-queue-prototype/pkg/inhouse_read_ui_bg.wasm')});ui.length_queue_prepare()})
afterEach(()=>{for(const q of queues.splice(0))q.dispose();expect(ui.ui_live_handles()).toBe(0)})
const create=(mode,library,options)=>{const q=mode==='rust'?createNativeLengthQueue(library,options,ui,helpers):createBookLengthQueue(library,options);queues.push(q);return q}
const base=()=>({id:'book',content:new Blob(['file']),contentRevision:'bytes',name:'book.epub'})
it.each(['object','id','ready','cancel','disposed','sync-measure-error','measure-error','change-error'])('preserves exact promise turns and callback order for %s',async scenario=>{
 const traces=[]
 for(const mode of ['legacy','rust']){
  const trace=[];let record=base();const failure=new Error('measure'),changeFailure=new Error('change')
  if(scenario==='ready')record={...record,...completeWordCount(123),wordCountContentRevision:'bytes'}
  const library={get:id=>{trace.push('get:'+id);return Promise.resolve(record)},patch:(id,fields,options)=>{trace.push('patch:'+id);if(options.ifCurrent(record)){record={...record,...fields};return Promise.resolve(record)}return Promise.resolve(null)}}
  const q=create(mode,library,{measureFile:()=>{trace.push('measure');if(scenario==='sync-measure-error')throw failure;if(scenario==='measure-error')return Promise.reject(failure);return Promise.resolve(completeWordCount(500))},onError:error=>trace.push('error:'+error.message),onChange:(book,meta)=>{trace.push('change:'+meta.status);if(scenario==='change-error'&&meta.status==='ready')throw changeFailure}})
  if(scenario==='disposed')q.dispose()
  const promise=q.ensure(scenario==='id'?'book':record);promise.then(value=>trace.push('done:'+(value?.wordCount??'null')),error=>trace.push('rejected:'+error.message));trace.push('requested')
  if(scenario==='cancel')q.cancel('book')
  for(let i=0;i<30;i++){await Promise.resolve();trace.push('turn:'+i)}await promise;traces.push(trace);q.dispose()
 }
 expect(traces[1]).toEqual(traces[0])
})
it.each([undefined,null,false,0,'',Symbol('failure')])('preserves early lookup rejection identity for %s',async reason=>{
 for(const mode of ['legacy','rust']){const error=vi.fn(),change=vi.fn(),q=create(mode,{get:()=>Promise.reject(reason)},{onError:error,onChange:change});await expect(q.ensure('book')).rejects.toBe(reason);expect(error).not.toHaveBeenCalled();expect(change).not.toHaveBeenCalled()}
})
it('keeps retry delegated through its receiver cancel method and emits pending synchronously',async()=>{
 for(const mode of ['legacy','rust']){const trace=[],record=base(),library={get:async()=>record,patch:async(id,fields)=>({...record,...fields})},q=create(mode,library,{measureFile:async()=>completeWordCount(30),onChange:(_,meta)=>trace.push(meta.status)}),cancel=vi.fn();const p=q.retry.call({cancel},record);expect(cancel).toHaveBeenCalledExactlyOnceWith('book');expect(trace).toEqual(['pending']);await p;expect(trace).toEqual(['pending','ready']);q.dispose()}
})
