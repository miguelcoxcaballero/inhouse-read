from pathlib import Path
root=Path('C:/Users/migue/Documents/InhouseRead-New');out=Path(__file__).parent
for name in ['book-length-queue-rust-prototype.test.js','book-length-queue-order-prototype.test.js']:
 p=root/'tests/unit'/name;s=p.read_text(encoding='utf8');(out/(name+'.before-intern')).write_bytes(s.encode('utf8'))
 s=s.replace("inhouse_read_ui_bg.wasm')}));", "inhouse_read_ui_bg.wasm')});ui.length_queue_prepare()});")
 s=s.replace("inhouse_read_ui_bg.wasm')}))", "inhouse_read_ui_bg.wasm')});ui.length_queue_prepare()})")
 s=s.replace('expect(ui.ui_live_handles()).toBe(0)','expect(ui.ui_live_handles()).toBe(20)')
 p.write_bytes(s.encode('utf8'))
