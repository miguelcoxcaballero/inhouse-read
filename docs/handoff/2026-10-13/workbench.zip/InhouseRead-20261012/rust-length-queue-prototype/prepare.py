from pathlib import Path
import shutil
root=Path('C:/Users/migue/Documents/InhouseRead-New');out=Path(__file__).parent
shutil.copytree(root/'rust-ui/src',out/'src',dirs_exist_ok=True)
shutil.copytree(root/'rust-core/src',out.parent/'rust-core/src',dirs_exist_ok=True)
for name in ['Cargo.toml','Cargo.lock']:shutil.copyfile(root/'rust-ui'/name,out/name)
shutil.copyfile(out/'length_queue.rs',out/'src/length_queue.rs')
p=out/'src/lib.rs';s=p.read_text(encoding='utf8');p.write_bytes(('mod length_queue;\n'+s).encode('utf8'))
