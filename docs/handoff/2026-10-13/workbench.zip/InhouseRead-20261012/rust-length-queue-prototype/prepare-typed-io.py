from pathlib import Path
out=Path(__file__).parent;p=out/'length_queue.rs';s=p.read_text(encoding='utf8');(out/'length_queue.before-typed-io.rs').write_bytes(s.encode('utf8'))
counts={'id':1,'ready':1,'revision':0,'get':1,'patch':3,'file':1,'measure':2,'complete':1,'fields':2,'change':2,'error':2,'ensure':1,'swallow':1,'task':1}
binding=['#[wasm_bindgen] extern "C" {',' type QueueOperations;']
for name,n in counts.items():
 arguments=''.join(f',a{i}:&JsValue' for i in range(n))
 binding.append(f' #[wasm_bindgen(method,catch,js_name={name})] fn io_{name}(this:&QueueOperations{arguments})->Result<JsValue,JsValue>;')
binding.append('}')
start=s.index('fn invoke(');end=s.index('fn callback(',start)
invoke='fn invoke(c:&JsValue,name:&str,args:&[JsValue])->Result<JsValue,JsValue>{let h=host(c)?;let io=h.unchecked_ref::<QueueOperations>();match name{'
for name,n in counts.items():invoke+=f'"{name}"=>io.io_{name}('+','.join(f'&args[{i}]' for i in range(n))+'),'
invoke+='_=>Err(js_sys::Error::new("Unknown queue IO").into())}}\n'
s=s[:start]+'\n'.join(binding)+'\n'+invoke+s[end:];p.write_bytes(s.encode('utf8'));(out/'src/length_queue.rs').write_bytes(s.encode('utf8'))
p=out/'factory.mjs';s=p.read_text(encoding='utf8');(out/'factory.before-typed-io.mjs').write_bytes(s.encode('utf8'));s=s.replace(" ensure=book=>", " for(const name of ['id','ready','revision','get','patch','file','measure','complete','fields','change','error','ensure','swallow','task'])host[name]=(...args)=>host.io(name,...args)\n ensure=book=>");p.write_bytes(s.encode('utf8'))
