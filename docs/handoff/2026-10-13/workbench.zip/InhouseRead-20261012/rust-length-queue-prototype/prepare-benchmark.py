from pathlib import Path
root=Path('C:/Users/migue/Documents/InhouseRead-New');out=Path(__file__).parent
s=(root/'src/js/book-length-queue.js').read_text(encoding='utf8')
s='\n'.join(line for line in s.splitlines() if not line.startswith('import '))
s="import {completeWordCount,hasCompleteWordCount} from './book-length.mjs';\n"+s
(out/'legacy.mjs').write_bytes(s.encode('utf8'))
(out/'book-length.mjs').write_bytes((root/'src/js/book-length.js').read_bytes())
