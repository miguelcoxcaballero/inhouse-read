from pathlib import Path
root=Path('C:/Users/migue/Documents/InhouseRead-New');out=Path(__file__).parent
p=out/'length_queue.rs';s=p.read_text(encoding='utf8');(out/'length_queue.before-cache-cleanup.rs').write_bytes(s.encode('utf8'))
s=s.replace('use js_sys::{Array,Function,Map,Object,Reflect};','use js_sys::{Function,Map,Object,Reflect};')
s=s.replace('JsValue::from_str(wasm_bindgen::intern(k))','JsValue::from_str(k)')
start=s.index('pub fn length_queue_prepare()');end=s.index('\n',start);s=s[:start]+'pub fn length_queue_prepare(){}'+s[end:]
p.write_bytes(s.encode('utf8'));(out/'src/length_queue.rs').write_bytes(s.encode('utf8'))
for name in ['book-length-queue-rust-prototype.test.js','book-length-queue-order-prototype.test.js']:
 p=root/'tests/unit'/name;s=p.read_text(encoding='utf8');(out/(name+'.before-cache-cleanup')).write_bytes(s.encode('utf8'));p.write_bytes(s.replace('ui.ui_live_handles()).toBe(21)','ui.ui_live_handles()).toBe(0)').encode('utf8'))
