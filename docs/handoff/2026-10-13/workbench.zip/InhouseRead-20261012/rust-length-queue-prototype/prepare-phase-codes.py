from pathlib import Path
out=Path(__file__).parent;p=out/'length_queue.rs';s=p.read_text(encoding='utf8');(out/'length_queue.before-phase-codes.rs').write_bytes(s.encode('utf8'))
phases=['ensure','record','patched','revised','new-revision-current','active','job','latest','measure-error','measured','commit-current','saved','job-error','reject','geometry','cancel','dispose','retry']
s=s.replace('stage:&str,value:JsValue','stage:u32,value:JsValue')
for i,name in enumerate(phases):s=s.replace('"'+name+'"=>',str(i)+'=>') if name in ['new-revision-current','active','job','latest','measure-error','measured','commit-current','saved','job-error','revised','patched','geometry','cancel','dispose','retry','reject'] else s
# Match only the outer dispatcher; property getter/IO matches stay strings.
s=(out/'length_queue.before-phase-codes.rs').read_text(encoding='utf8').replace('stage:&str,value:JsValue','stage:u32,value:JsValue')
start=s.index(' match stage{');head=s[:start];body=s[start:]
for i,name in enumerate(phases):body=body.replace('"'+name+'"=>',str(i)+'=>')
s=head+body;p.write_bytes(s.encode('utf8'));(out/'src/length_queue.rs').write_bytes(s.encode('utf8'))
p=out/'factory.mjs';s=p.read_text(encoding='utf8');(out/'factory.before-phase-codes.mjs').write_bytes(s.encode('utf8'));codes='{'+','.join(repr(name)+':'+str(i) for i,name in enumerate(phases))+'}'
s=s.replace(' const step=(context,phase,value)=>core.length_queue_step(context,phase,value)',f' const phases={codes}\n const step=(context,phase,value)=>core.length_queue_step(context,phases[phase],value)');p.write_bytes(s.encode('utf8'))
