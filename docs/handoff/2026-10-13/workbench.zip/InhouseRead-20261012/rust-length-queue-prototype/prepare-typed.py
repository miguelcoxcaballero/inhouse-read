from pathlib import Path
out=Path(__file__).parent;p=out/'length_queue.rs';s=p.read_text(encoding='utf8');(out/'length_queue.before-typed.rs').write_bytes(s.encode('utf8'))
keys=['host','io','callback','resolve','wait','entries','disposed','entry','cancelled','id','record','revision','contentRevision','task','status','content','latest','reject','receiver','tail','cancel']
binding=['#[wasm_bindgen] extern "C" {',' type QueueFields;']
for i,key in enumerate(keys):
 binding.extend([f' #[wasm_bindgen(method,getter,catch,js_name={key})] fn read_{i}(this:&QueueFields)->Result<JsValue,JsValue>;',f' #[wasm_bindgen(method,setter,catch,js_name={key})] fn write_{i}(this:&QueueFields,value:&JsValue)->Result<(),JsValue>;'])
binding.append('}')
start=s.index('fn get(');end=s.index('fn optional(',start)
get='fn get(o:&JsValue,k:&str)->Result<JsValue,JsValue>{let object=o.unchecked_ref::<QueueFields>();match k{'+''.join(f'"{key}"=>object.read_{i}(),' for i,key in enumerate(keys))+'_=>Reflect::get(o,&key(k))}}\n'
s=s[:start]+'\n'.join(binding)+'\n'+get+s[end:]
start=s.index('fn put(');end=s.index('fn host(',start)
put='fn put(o:&JsValue,k:&str,v:&JsValue)->Result<(),JsValue>{let object=o.unchecked_ref::<QueueFields>();match k{'+''.join(f'"{key}"=>object.write_{i}(v),' for i,key in enumerate(keys))+'_=>{if Reflect::set(o,&key(k),v)?{Ok(())}else{Err(js_sys::TypeError::new("Read-only queue field").into())}}}}\n'
s=s[:start]+put+s[end:];p.write_bytes(s.encode('utf8'));(out/'src/length_queue.rs').write_bytes(s.encode('utf8'))
