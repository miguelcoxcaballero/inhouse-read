from pathlib import Path
out=Path(__file__).parent
s=(out/'legacy.mjs').read_text(encoding='utf8')
s=s.replace('    ensure, geometryState,','''    ensure, geometryState,
    transferState() { return {
      get entries() { return entries },
      get tail() { return tail }, set tail(value) { tail = value },
      get disposed() { return disposed }, set disposed(value) { disposed = value },
      options: { measureFile, onChange, onError }
    } },''')
assert 'transferState()' in s
(out/'legacy-shared.mjs').write_bytes(s.encode('utf8'))
