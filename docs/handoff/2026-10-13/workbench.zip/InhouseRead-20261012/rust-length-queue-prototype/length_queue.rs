//! Word-length job decisions. Browser promises, files and records stay opaque.
use wasm_bindgen::prelude::*;
use js_sys::{Function,Map,Object,Reflect};
use wasm_bindgen::JsCast;
use std::{cell::Cell,rc::Rc};
thread_local!{static SCOPES:Cell<u32>=const{Cell::new(0)};static GUARDS:Cell<u32>=const{Cell::new(0)};}
#[wasm_bindgen] pub fn length_queue_scopes()->u32{SCOPES.with(Cell::get)}
#[wasm_bindgen] pub fn length_queue_guards()->u32{GUARDS.with(Cell::get)}
#[wasm_bindgen]
pub struct RustLengthLifetime{disposed:Rc<Cell<bool>>}
#[wasm_bindgen]
impl RustLengthLifetime{
 #[wasm_bindgen(constructor)] pub fn new(value:JsValue)->Self{SCOPES.with(|n|n.set(n.get()+1));Self{disposed:Rc::new(Cell::new(value.is_truthy()))}}
 #[wasm_bindgen(js_name=setDisposed)] pub fn set_disposed(&self,value:JsValue){self.disposed.set(value.is_truthy())}
}
impl Drop for RustLengthLifetime{fn drop(&mut self){SCOPES.with(|n|n.set(n.get()-1));}}
#[wasm_bindgen]
pub struct RustLengthGuard{disposed:Rc<Cell<bool>>,cancelled:Cell<bool>}
#[wasm_bindgen]
impl RustLengthGuard{
 #[wasm_bindgen(constructor)] pub fn new(owner:&RustLengthLifetime,value:JsValue)->Self{GUARDS.with(|n|n.set(n.get()+1));Self{disposed:owner.disposed.clone(),cancelled:Cell::new(value.is_truthy())}}
 #[wasm_bindgen(js_name=setCancelled)] pub fn set_cancelled(&self,value:JsValue){self.cancelled.set(value.is_truthy())}
 pub fn active(&self)->bool{!self.disposed.get()&&!self.cancelled.get()}
}
impl Drop for RustLengthGuard{fn drop(&mut self){GUARDS.with(|n|n.set(n.get()-1));}}
#[wasm_bindgen] extern "C" {#[wasm_bindgen(js_name=Object,catch)]fn boxed(v:&JsValue)->Result<JsValue,JsValue>;}
fn key(k:&str)->JsValue{JsValue::from_str(k)}
#[wasm_bindgen]
pub fn length_queue_prepare(){}
#[wasm_bindgen] extern "C" {
 type QueueFields;
 #[wasm_bindgen(method,getter,catch,js_name=host)] fn read_0(this:&QueueFields)->Result<JsValue,JsValue>;
 #[wasm_bindgen(method,setter,catch,js_name=host)] fn write_0(this:&QueueFields,value:&JsValue)->Result<(),JsValue>;
 #[wasm_bindgen(method,getter,catch,js_name=io)] fn read_1(this:&QueueFields)->Result<JsValue,JsValue>;
 #[wasm_bindgen(method,setter,catch,js_name=io)] fn write_1(this:&QueueFields,value:&JsValue)->Result<(),JsValue>;
 #[wasm_bindgen(method,getter,catch,js_name=callback)] fn read_2(this:&QueueFields)->Result<JsValue,JsValue>;
 #[wasm_bindgen(method,setter,catch,js_name=callback)] fn write_2(this:&QueueFields,value:&JsValue)->Result<(),JsValue>;
 #[wasm_bindgen(method,getter,catch,js_name=resolve)] fn read_3(this:&QueueFields)->Result<JsValue,JsValue>;
 #[wasm_bindgen(method,setter,catch,js_name=resolve)] fn write_3(this:&QueueFields,value:&JsValue)->Result<(),JsValue>;
 #[wasm_bindgen(method,getter,catch,js_name=wait)] fn read_4(this:&QueueFields)->Result<JsValue,JsValue>;
 #[wasm_bindgen(method,setter,catch,js_name=wait)] fn write_4(this:&QueueFields,value:&JsValue)->Result<(),JsValue>;
 #[wasm_bindgen(method,getter,catch,js_name=entries)] fn read_5(this:&QueueFields)->Result<JsValue,JsValue>;
 #[wasm_bindgen(method,setter,catch,js_name=entries)] fn write_5(this:&QueueFields,value:&JsValue)->Result<(),JsValue>;
 #[wasm_bindgen(method,getter,catch,js_name=disposed)] fn read_6(this:&QueueFields)->Result<JsValue,JsValue>;
 #[wasm_bindgen(method,setter,catch,js_name=disposed)] fn write_6(this:&QueueFields,value:&JsValue)->Result<(),JsValue>;
 #[wasm_bindgen(method,getter,catch,js_name=entry)] fn read_7(this:&QueueFields)->Result<JsValue,JsValue>;
 #[wasm_bindgen(method,setter,catch,js_name=entry)] fn write_7(this:&QueueFields,value:&JsValue)->Result<(),JsValue>;
 #[wasm_bindgen(method,getter,catch,js_name=cancelled)] fn read_8(this:&QueueFields)->Result<JsValue,JsValue>;
 #[wasm_bindgen(method,setter,catch,js_name=cancelled)] fn write_8(this:&QueueFields,value:&JsValue)->Result<(),JsValue>;
 #[wasm_bindgen(method,getter,catch,js_name=id)] fn read_9(this:&QueueFields)->Result<JsValue,JsValue>;
 #[wasm_bindgen(method,setter,catch,js_name=id)] fn write_9(this:&QueueFields,value:&JsValue)->Result<(),JsValue>;
 #[wasm_bindgen(method,getter,catch,js_name=record)] fn read_10(this:&QueueFields)->Result<JsValue,JsValue>;
 #[wasm_bindgen(method,setter,catch,js_name=record)] fn write_10(this:&QueueFields,value:&JsValue)->Result<(),JsValue>;
 #[wasm_bindgen(method,getter,catch,js_name=revision)] fn read_11(this:&QueueFields)->Result<JsValue,JsValue>;
 #[wasm_bindgen(method,setter,catch,js_name=revision)] fn write_11(this:&QueueFields,value:&JsValue)->Result<(),JsValue>;
 #[wasm_bindgen(method,getter,catch,js_name=contentRevision)] fn read_12(this:&QueueFields)->Result<JsValue,JsValue>;
 #[wasm_bindgen(method,setter,catch,js_name=contentRevision)] fn write_12(this:&QueueFields,value:&JsValue)->Result<(),JsValue>;
 #[wasm_bindgen(method,getter,catch,js_name=task)] fn read_13(this:&QueueFields)->Result<JsValue,JsValue>;
 #[wasm_bindgen(method,setter,catch,js_name=task)] fn write_13(this:&QueueFields,value:&JsValue)->Result<(),JsValue>;
 #[wasm_bindgen(method,getter,catch,js_name=status)] fn read_14(this:&QueueFields)->Result<JsValue,JsValue>;
 #[wasm_bindgen(method,setter,catch,js_name=status)] fn write_14(this:&QueueFields,value:&JsValue)->Result<(),JsValue>;
 #[wasm_bindgen(method,getter,catch,js_name=content)] fn read_15(this:&QueueFields)->Result<JsValue,JsValue>;
 #[wasm_bindgen(method,setter,catch,js_name=content)] fn write_15(this:&QueueFields,value:&JsValue)->Result<(),JsValue>;
 #[wasm_bindgen(method,getter,catch,js_name=latest)] fn read_16(this:&QueueFields)->Result<JsValue,JsValue>;
 #[wasm_bindgen(method,setter,catch,js_name=latest)] fn write_16(this:&QueueFields,value:&JsValue)->Result<(),JsValue>;
 #[wasm_bindgen(method,getter,catch,js_name=reject)] fn read_17(this:&QueueFields)->Result<JsValue,JsValue>;
 #[wasm_bindgen(method,setter,catch,js_name=reject)] fn write_17(this:&QueueFields,value:&JsValue)->Result<(),JsValue>;
 #[wasm_bindgen(method,getter,catch,js_name=receiver)] fn read_18(this:&QueueFields)->Result<JsValue,JsValue>;
 #[wasm_bindgen(method,setter,catch,js_name=receiver)] fn write_18(this:&QueueFields,value:&JsValue)->Result<(),JsValue>;
 #[wasm_bindgen(method,getter,catch,js_name=tail)] fn read_19(this:&QueueFields)->Result<JsValue,JsValue>;
 #[wasm_bindgen(method,setter,catch,js_name=tail)] fn write_19(this:&QueueFields,value:&JsValue)->Result<(),JsValue>;
 #[wasm_bindgen(method,getter,catch,js_name=cancel)] fn read_20(this:&QueueFields)->Result<JsValue,JsValue>;
 #[wasm_bindgen(method,setter,catch,js_name=cancel)] fn write_20(this:&QueueFields,value:&JsValue)->Result<(),JsValue>;
}
fn get(o:&JsValue,k:&str)->Result<JsValue,JsValue>{let object=o.unchecked_ref::<QueueFields>();match k{"host"=>object.read_0(),"io"=>object.read_1(),"callback"=>object.read_2(),"resolve"=>object.read_3(),"wait"=>object.read_4(),"entries"=>object.read_5(),"disposed"=>object.read_6(),"entry"=>object.read_7(),"cancelled"=>object.read_8(),"id"=>object.read_9(),"record"=>object.read_10(),"revision"=>object.read_11(),"contentRevision"=>object.read_12(),"task"=>object.read_13(),"status"=>object.read_14(),"content"=>object.read_15(),"latest"=>object.read_16(),"reject"=>object.read_17(),"receiver"=>object.read_18(),"tail"=>object.read_19(),"cancel"=>object.read_20(),_=>Reflect::get(o,&key(k))}}
fn optional(o:&JsValue,k:&str)->Result<JsValue,JsValue>{if o.is_null()||o.is_undefined(){Ok(JsValue::UNDEFINED)}else{get(o,k)}}
fn put(o:&JsValue,k:&str,v:&JsValue)->Result<(),JsValue>{let object=o.unchecked_ref::<QueueFields>();match k{"host"=>object.write_0(v),"io"=>object.write_1(v),"callback"=>object.write_2(v),"resolve"=>object.write_3(v),"wait"=>object.write_4(v),"entries"=>object.write_5(v),"disposed"=>object.write_6(v),"entry"=>object.write_7(v),"cancelled"=>object.write_8(v),"id"=>object.write_9(v),"record"=>object.write_10(v),"revision"=>object.write_11(v),"contentRevision"=>object.write_12(v),"task"=>object.write_13(v),"status"=>object.write_14(v),"content"=>object.write_15(v),"latest"=>object.write_16(v),"reject"=>object.write_17(v),"receiver"=>object.write_18(v),"tail"=>object.write_19(v),"cancel"=>object.write_20(v),_=>{if Reflect::set(o,&key(k),v)?{Ok(())}else{Err(js_sys::TypeError::new("Read-only queue field").into())}}}}
fn host(c:&JsValue)->Result<JsValue,JsValue>{get(c,"host")}
#[wasm_bindgen] extern "C" {
 type QueueOperations;
 #[wasm_bindgen(method,catch,js_name=id)] fn io_id(this:&QueueOperations,a0:&JsValue)->Result<JsValue,JsValue>;
 #[wasm_bindgen(method,catch,js_name=ready)] fn io_ready(this:&QueueOperations,a0:&JsValue)->Result<JsValue,JsValue>;
 #[wasm_bindgen(method,catch,js_name=revision)] fn io_revision(this:&QueueOperations)->Result<JsValue,JsValue>;
 #[wasm_bindgen(method,catch,js_name=get)] fn io_get(this:&QueueOperations,a0:&JsValue)->Result<JsValue,JsValue>;
 #[wasm_bindgen(method,catch,js_name=patch)] fn io_patch(this:&QueueOperations,a0:&JsValue,a1:&JsValue,a2:&JsValue)->Result<JsValue,JsValue>;
 #[wasm_bindgen(method,catch,js_name=file)] fn io_file(this:&QueueOperations,a0:&JsValue)->Result<JsValue,JsValue>;
 #[wasm_bindgen(method,catch,js_name=measure)] fn io_measure(this:&QueueOperations,a0:&JsValue,a1:&JsValue)->Result<JsValue,JsValue>;
 #[wasm_bindgen(method,catch,js_name=complete)] fn io_complete(this:&QueueOperations,a0:&JsValue)->Result<JsValue,JsValue>;
 #[wasm_bindgen(method,catch,js_name=fields)] fn io_fields(this:&QueueOperations,a0:&JsValue,a1:&JsValue)->Result<JsValue,JsValue>;
 #[wasm_bindgen(method,catch,js_name=change)] fn io_change(this:&QueueOperations,a0:&JsValue,a1:&JsValue)->Result<JsValue,JsValue>;
 #[wasm_bindgen(method,catch,js_name=error)] fn io_error(this:&QueueOperations,a0:&JsValue,a1:&JsValue)->Result<JsValue,JsValue>;
 #[wasm_bindgen(method,catch,js_name=ensure)] fn io_ensure(this:&QueueOperations,a0:&JsValue)->Result<JsValue,JsValue>;
 #[wasm_bindgen(method,catch,js_name=swallow)] fn io_swallow(this:&QueueOperations,a0:&JsValue)->Result<JsValue,JsValue>;
 #[wasm_bindgen(method,catch,js_name=task)] fn io_task(this:&QueueOperations,a0:&JsValue)->Result<JsValue,JsValue>;
}
fn invoke(c:&JsValue,name:&str,args:&[JsValue])->Result<JsValue,JsValue>{let h=host(c)?;let io=h.unchecked_ref::<QueueOperations>();match name{"id"=>io.io_id(&args[0]),"ready"=>io.io_ready(&args[0]),"revision"=>io.io_revision(),"get"=>io.io_get(&args[0]),"patch"=>io.io_patch(&args[0],&args[1],&args[2]),"file"=>io.io_file(&args[0]),"measure"=>io.io_measure(&args[0],&args[1]),"complete"=>io.io_complete(&args[0]),"fields"=>io.io_fields(&args[0],&args[1]),"change"=>io.io_change(&args[0],&args[1]),"error"=>io.io_error(&args[0],&args[1]),"ensure"=>io.io_ensure(&args[0]),"swallow"=>io.io_swallow(&args[0]),"task"=>io.io_task(&args[0]),_=>Err(js_sys::Error::new("Unknown queue IO").into())}}
fn callback(c:&JsValue,name:&str)->Result<JsValue,JsValue>{get(&host(c)?,"callback")?.unchecked_into::<Function>().call2(&JsValue::UNDEFINED,&name.into(),c)}
fn finish(c:&JsValue,v:&JsValue)->Result<(),JsValue>{get(c,"resolve")?.unchecked_into::<Function>().call1(&JsValue::UNDEFINED,v)?;Ok(())}
fn wait(c:&JsValue,p:&JsValue,ok:&str,error:&str)->Result<(),JsValue>{get(&host(c)?,"wait")?.unchecked_into::<Function>().call4(&JsValue::UNDEFINED,c,p,&ok.into(),&error.into())?;Ok(())}
fn map(c:&JsValue)->Result<Map,JsValue>{Ok(get(&host(c)?,"entries")?.unchecked_into())}
fn disposed(c:&JsValue)->Result<bool,JsValue>{Ok(get(&host(c)?,"disposed")?.is_truthy())}
fn active(c:&JsValue)->Result<bool,JsValue>{if disposed(c)?{return Ok(false)}let entry=get(c,"entry")?;Ok(!get(&entry,"cancelled")?.is_truthy()&&map(c)?.get(&get(c,"id")?)==entry)}
fn ready(c:&JsValue,b:&JsValue)->Result<bool,JsValue>{Ok(invoke(c,"ready",&[b.clone()])?.is_truthy())}
fn status(c:&JsValue,name:&str)->Result<JsValue,JsValue>{let value=Object::new();put(&value,"id",&get(c,"id")?)?;put(&value,"status",&name.into())?;Ok(value.into())}
fn announce(c:&JsValue,b:&JsValue,name:&str)->Result<(),JsValue>{invoke(c,"change",&[b.clone(),status(c,name)?])?;Ok(())}
fn schedule(c:&JsValue)->Result<(),JsValue>{
 let record=get(c,"record")?;let id=get(c,"id")?;let entries=map(c)?;let previous=entries.get(&id);let revision=get(&record,"contentRevision")?;
 if previous.is_truthy()&&get(&previous,"revision")?==revision{return finish(c,&get(&previous,"task")?)}
 if previous.is_truthy(){put(&previous,"cancelled",&true.into())?;}
 let entry=Object::new();put(&entry,"revision",&revision)?;put(&entry,"status",&"pending".into())?;put(&entry,"cancelled",&false.into())?;put(&entry,"task",&JsValue::NULL)?;put(c,"entry",&entry)?;
 let task=invoke(c,"task",&[c.clone()])?;put(&entry,"task",&task)?;entries.set(&id,&entry);let tail=invoke(c,"swallow",&[task.clone()])?;put(&host(c)?,"tail",&tail)?;finish(c,&task)
}
fn record(c:&JsValue,b:JsValue,revised:bool)->Result<(),JsValue>{
 put(c,"record",&b)?;
 if revised{if !optional(&b,"content")?.is_truthy()||disposed(c)?{return finish(c,&JsValue::NULL)}if ready(c,&b)?{return finish(c,&b)}}
 else{
  if !b.is_truthy()||disposed(c)?||ready(c,&b)?||!get(&b,"content")?.is_truthy(){return finish(c,&if b.is_truthy(){b}else{JsValue::NULL})}
  if !get(&b,"contentRevision")?.is_truthy(){let revision=invoke(c,"revision",&[])?;let fields=Object::new();put(&fields,"contentRevision",&revision)?;let p=invoke(c,"patch",&[get(c,"id")?,fields.into(),callback(c,"new-revision-current")?])?;return wait(c,&p,"patched","reject")}
 }
 schedule(c)
}
fn measured(c:&JsValue,v:JsValue)->Result<(),JsValue>{
 if !active(c)?{return finish(c,&JsValue::NULL)}
 let length=invoke(c,"complete",&[v])?;
 if !length.is_truthy(){put(&get(c,"entry")?,"status",&"failed".into())?;announce(c,&JsValue::NULL,"failed")?;return finish(c,&JsValue::NULL)}
 let fields=invoke(c,"fields",&[length,get(&get(c,"entry")?,"revision")?])?;
 let p=invoke(c,"patch",&[get(c,"id")?,fields,callback(c,"commit-current")?])?;wait(c,&p,"saved","reject")
}
#[wasm_bindgen]
pub fn length_queue_active(c:JsValue)->Result<bool,JsValue>{active(&c)}
#[wasm_bindgen]
pub fn length_queue_step(c:JsValue,stage:u32,value:JsValue)->Result<JsValue,JsValue>{
 match stage{
  0=>{
   if disposed(&c)?{finish(&c,&JsValue::NULL)?;return Ok(JsValue::UNDEFINED)}
   let id=invoke(&c,"id",&[value.clone()])?;put(&c,"id",&id)?;
   if value.js_typeof()==JsValue::from_str("object"){record(&c,value,false)?}
   else if id.is_truthy(){let p=invoke(&c,"get",&[id])?;wait(&c,&p,"record","reject")?}
   else{record(&c,id,false)?}
  },
  1=>record(&c,value,false)?,
  2=>if value.is_truthy(){record(&c,value,true)?}else{let p=invoke(&c,"get",&[get(&c,"id")?])?;wait(&c,&p,"revised","reject")?},
  3=>record(&c,value,true)?,
  4=>return Ok((get(&value,"content")?.is_truthy()&&!get(&value,"contentRevision")?.is_truthy()).into()),
  5=>return Ok(active(&c)?.into()),
  6=>{if !active(&c)?{finish(&c,&JsValue::NULL)?}else{let p=invoke(&c,"get",&[get(&c,"id")?])?;wait(&c,&p,"latest","reject")?}},
  7=>{
   if !value.is_truthy()||get(&value,"contentRevision")?!=get(&get(&c,"entry")?,"revision")?||!get(&value,"content")?.is_truthy(){finish(&c,&JsValue::NULL)?}
   else{put(&c,"latest",&value)?;let file=invoke(&c,"file",&[value])?;match invoke(&c,"measure",&[file,callback(&c,"active")?]){Ok(p)=>wait(&c,&p,"measured","measure-error")?,Err(error)=>{if active(&c)?{invoke(&c,"error",&[error,get(&c,"latest")?])?;}measured(&c,JsValue::UNDEFINED)?;}}}
  },
  8=>{if active(&c)?{invoke(&c,"error",&[value,get(&c,"latest")?])?;}measured(&c,JsValue::UNDEFINED)?},
  9=>measured(&c,value)?,
  10=>return Ok((active(&c)?&&get(&value,"content")?.is_truthy()&&get(&value,"contentRevision")?==get(&get(&c,"entry")?,"revision")?).into()),
  11=>{if value.is_truthy(){put(&get(&c,"entry")?,"status",&"ready".into())?;announce(&c,&value,"ready")?;}finish(&c,&value)?},
  12=>{if active(&c)?{put(&get(&c,"entry")?,"status",&"failed".into())?;invoke(&c,"error",&[value,get(&c,"record")?])?;announce(&c,&JsValue::NULL,"failed")?;}return Ok(JsValue::NULL)},
  13=>{get(&c,"reject")?.unchecked_into::<Function>().call1(&JsValue::UNDEFINED,&value)?;},
  14=>{
   if ready(&c,&value)?{return Ok("ready".into())}
   let entry=map(&c)?.get(&optional(&value,"id")?);
   if optional(&entry,"revision")?==optional(&value,"contentRevision")?&&optional(&entry,"status")?==JsValue::from_str("failed"){return Ok("failed".into())}
   return Ok(if optional(&value,"content")?.is_truthy(){"pending"}else{"needs-source"}.into())
  },
  15=>{let entries=map(&c)?;let entry=entries.get(&value);if entry.is_truthy(){put(&entry,"cancelled",&true.into())?;}entries.delete(&value);},
  16=>{put(&host(&c)?,"disposed",&true.into())?;for entry in js_sys::try_iter(&map(&c)?.values())?.ok_or_else(||js_sys::TypeError::new("Missing queue iterator"))?{put(&entry?,"cancelled",&true.into())?;}map(&c)?.clear();},
  17=>{let id=invoke(&c,"id",&[value.clone()])?;let receiver=get(&c,"receiver")?;get(&receiver,"cancel")?.unchecked_into::<Function>().call1(&receiver,&id)?;let task=invoke(&c,"ensure",&[value])?;put(&c,"id",&id)?;announce(&c,&JsValue::NULL,"pending")?;return Ok(task)},
  _=>return Err(js_sys::Error::new("Unknown length queue phase").into())
 }
 Ok(JsValue::UNDEFINED)
}
