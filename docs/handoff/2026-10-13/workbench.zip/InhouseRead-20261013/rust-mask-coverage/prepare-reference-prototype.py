from pathlib import Path
import shutil
source=Path('D:/CodexEvidence/InhouseRead-20261013/rust-length-queue-host-prototype')
out=Path('D:/CodexEvidence/InhouseRead-20261013/rust-length-queue-reference-prototype')
out.mkdir(exist_ok=True)
for name in ['Cargo.toml','Cargo.lock','factory.mjs','book-length.mjs','legacy.mjs','legacy-shared.mjs','benchmark.mjs','memory.mjs','import-profile.mjs']:
 shutil.copyfile(source/name,out/name)
shutil.copytree(source/'src',out/'src',dirs_exist_ok=True)
p=out/'Cargo.toml';s=p.read_text(encoding='utf8');assert 'strip = "symbols"' in s;p.write_text(s.replace('strip = "symbols"','strip = "debuginfo"'),encoding='utf8')
for name in ['benchmark.mjs','memory.mjs','import-profile.mjs']:
 p=out/name;s=p.read_text(encoding='utf8').replace('4514','4517').replace('4515','4518').replace('4516','4519');p.write_bytes(s.encode('utf8'))
s=Path('D:/CodexEvidence/InhouseRead-20261012/build-ui-prototype-105.ps1').read_text(encoding='utf8')
s=s.replace('-reference-types,-multivalue','+reference-types,-multivalue')
s=s.replace(' --target web --out-dir ', ' --target web --remove-name-section --out-dir ')
(out/'build.ps1').write_bytes(s.encode('utf8'))
print(out)
