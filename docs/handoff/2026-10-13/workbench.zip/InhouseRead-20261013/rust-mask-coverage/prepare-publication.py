from pathlib import Path
import hashlib
root=Path('C:/Users/migue/Documents/InhouseRead-New')
base=Path('D:/CodexEvidence/InhouseRead-20261012')
out=Path(__file__).parent
sha=hashlib.sha256((root/'src/wasm/inhouse_read_core.wasm').read_bytes()).hexdigest()
s=(base/'verify-public-233.mjs').read_text(encoding='utf8')
s=s.replace('1.7.233','1.7.234').replace('eaccdb0c22f00819e753a64241e868365d9e0d23c8b068a9d46825467a081305',sha)
s=s.replace("'studio_half_scan'])check('compiled", "'studio_half_scan','relief_color_mask_count'])check('compiled")
s=s.replace("root='D:/CodexEvidence/InhouseRead-20261012'", "root='D:/CodexEvidence/InhouseRead-20261013'")
(out/'verify-public-234.mjs').write_bytes(s.encode('utf8'))
s=(base/'rust-studio-scan-prototype/native-ui233.py').read_text(encoding='utf8').replace('1.7.233','1.7.234').replace('native-ui233','native-ui234')
s=s.replace('D:/CodexEvidence/InhouseRead-20261012/rust-studio-scan-prototype',str(out).replace('\\','/'))
(out/'native-ui234.py').write_bytes(s.encode('utf8'))
