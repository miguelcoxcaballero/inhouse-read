from pathlib import Path
import json
root=Path('C:/Users/migue/Documents/InhouseRead-New');out=Path(__file__).parent
artifact=Path('D:/CodexEvidence/InhouseRead-20261013/published-1791907805581')
proof=json.loads((artifact/'summary.json').read_text(encoding='utf8'));assert proof['errors']==[]
native=json.loads((out/'native-ui234.json').read_text(encoding='utf8'));assert native['status']=='passed' and native['visibleVersion']=='1.7.234'
assert '15a1f89c7a6fe7476bee6eaf48cc78239b5a5cb05f98daa4d3c02a6bc73284bd' in (artifact/'apk-signature.log').read_text()
for filename,text in [('public-pdf-original.log','2 passed'),('public-scene-original.log','18 passed'),('public-profile-original.log','3 passed')]:assert text in (out/filename).read_text(encoding='utf8')
d={'version':'1.7.234','source':proof['source'],'deploy':38427723866,'pages':38427883697,'pagesSha':proof['pages'],'artifact':str(artifact),'ci':38427723850,'ciStatus':'in_progress','rustPercent':16.38,'apkVersion':'1.1.15','versionCode':28,'nativePid':native['pid']}
(out/'publication.json').write_bytes(json.dumps(d,indent=2).encode('utf8'))
p=root/'docs/remaining-wip-verification.md';s=p.read_text(encoding='utf8').replace('# 1.7.234 — cobertura de colores en la misma pasada Rust (local)','# 1.7.234 — cobertura de colores en la misma pasada Rust')
s=s.replace('comprobado remoto, sin editar copias. Publicación y prueba pública de 234\npendientes; no se afirma la corrección del cierre fallido en CI 233.',f'''comprobado remoto, sin editar copias. Publicación 234 comprobada:
main {proof['source']}; Deploy 38427723866 y Pages 38427883697 aprobados,
Pages {proof['pages']}. Los 109 recursos coinciden por HTTP, tamaño,
SHA y atribución. App WASM público {proof['wasm']['bytes']} bytes, SHA256
{proof['wasm']['sha256']}, igual al compilado local. UI público
{proof['ui']['bytes']} bytes, SHA256 {proof['ui']['sha256']}; se compara con
Pages sin presumir igualdad entre Linux y Windows. Dos perfiles exactos,
una instancia UI y referencias 515→533→515 estables tras 1000 preparaciones
y 100 menús; 30 PCM aprobados. 2 PDF/42.5 s, 18 escena/editor/3.6 min
y 3 perfil/updater/15.1 s públicos aprobados. El editor público exige las
llamadas Rust nuevas, su recuento exacto y la caché sin recálculo.
APK descargado por bytes, SHA, tamaño, firma, paquete y manifiesto;
loader 2107 bytes/3 assets. Android mostró 234/PID {native['pid']}, importó
content URI real y reprodujo Lessac 2× durante {native['cases'][0]['cumulativePlayedSeconds']:.10f} s acumulados,
8 done/9 start, mismo proceso y sin FATAL. No sustituye un teléfono físico.
CI 234/38427723850 continúa; no se afirma aprobación global ni corrección
universal del cierre fallido de CI 233.''')
s=s.replace('Se retiene para optimizar el puente, sin publicar una regresión ni afirmar\nque represente el coste del parser o IndexedDB reales.','''Se retiene para optimizar el puente, sin publicar una regresión ni afirmar
que represente el coste del parser o IndexedDB reales. El guard aislado
tampoco mejora: 100 trabajos/1000 consultas, 4.60→4.90 ms CPU×4, incluyendo
construcción/cancelación/liberación. Benchmark separado sin I/O; no se integra.''')
p.write_bytes(s.encode('utf8'))
p=root/'docs/rust-migration.md';s=p.read_text(encoding='utf8').replace('Entrega local 1.7.234','Entrega publicada 1.7.234')
s=s.replace('Publicación y comprobación pública de 234 pendientes. Web 233 y APK real\nverificados; CI 233 falla en cierres de 8 s. CI completa 232 aprobada.','Web 234 y APK real verificados: 109 recursos, 2 PDF, 18 escena/editor,\n3 perfil y audio Android 2×. CI 234 en curso; CI 233 falla en cierres de\n8 s. CI completa 232 aprobada.')
p.write_bytes(s.encode('utf8'))
