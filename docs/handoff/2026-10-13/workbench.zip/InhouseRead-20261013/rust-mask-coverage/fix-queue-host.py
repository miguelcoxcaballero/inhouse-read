from pathlib import Path
out=Path('D:/CodexEvidence/InhouseRead-20261013/rust-length-queue-host-prototype')
p=out/'src/length_queue.rs';s=p.read_text(encoding='utf8')
assert 'let host=get(&c,"host")?;let c=Context{value:c,host};' in s
s=s.replace('let host=get(&c,"host")?;let c=Context{value:c,host};','let owner=get(&c,"host")?;let c=Context{value:c,host:owner};')
s=s.replace('invoke(c,"task",&[c.clone()])','invoke(c,"task",&[c.value.clone()])')
p.write_bytes(s.encode('utf8'));(out/'length_queue.rs').write_bytes(s.encode('utf8'))
