import {createServer} from 'node:http';
import {readFile,writeFile} from 'node:fs/promises';
import {chromium} from 'file:///C:/Users/migue/Documents/InhouseRead-New/node_modules/playwright/index.mjs';
const prototype='D:/CodexEvidence/InhouseRead-20261012/rust-length-queue-prototype/pkg/';
const server=createServer(async(req,res)=>{try{const name=req.url==='/'?'index.html':req.url.slice(1);if(name==='index.html'){res.setHeader('Content-Type','text/html');return res.end('<title>Cancellation guard</title>');}if(!['inhouse_read_ui.js','inhouse_read_ui_bg.wasm'].includes(name)){res.writeHead(404);return res.end();}res.setHeader('Content-Type',name.endsWith('wasm')?'application/wasm':'text/javascript');res.end(await readFile(prototype+name));}catch(e){res.writeHead(500);res.end(String(e));}});
await new Promise(resolve=>server.listen(4513,'127.0.0.1',resolve));const browser=await chromium.launch({headless:true});
try{const page=await browser.newPage();await page.goto('http://127.0.0.1:4513/');await(await page.context().newCDPSession(page)).send('Emulation.setCPUThrottlingRate',{rate:4});
 const results=await page.evaluate(async()=>{const ui=await import('./inhouse_read_ui.js');await ui.default();const results=[],median=v=>[...v].sort((a,b)=>a-b)[4];
 for(const checks of [0,20,1000,10000]){
  const run=native=>{let checksum=0;const entries=new Map(),lifetime=native?new ui.RustLengthLifetime(false):null;let disposed=false;
   try{for(let job=0;job<100;job++){
    const id=String(job),entry={cancelled:false},guard=native?new ui.RustLengthGuard(lifetime,false):null;entries.set(id,entry);
    const active=native?()=>guard.active():()=>!disposed&&!entry.cancelled&&entries.get(id)===entry;
    for(let i=0;i<checks;i++)checksum+=active()?1:0;
    entry.cancelled=true;guard?.setCancelled(true);if(active())throw Error('Cancellation ignored');guard?.free();
   }disposed=true;lifetime?.setDisposed(true);return checksum;}finally{lifetime?.free();}
  };
  const expected=100*checks;if(run(false)!==expected||run(true)!==expected)throw Error('Parity');for(let i=0;i<5;i++){run(false);run(true);}const js=[],rust=[];
  for(let r=0;r<9;r++)for(const native of r%2?[true,false]:[false,true]){const at=performance.now();if(run(native)!==expected)throw Error('Result');(native?rust:js).push(performance.now()-at);}
  if(ui.length_queue_scopes()||ui.length_queue_guards()||ui.ui_live_handles())throw Error('Live allocation');results.push({jobs:100,checksPerJob:checks,js,rust,jsMedian:median(js),rustMedian:median(rust)});
 }return results;});await writeFile(new URL('benchmark-guard.json',import.meta.url),JSON.stringify({cpuThrottle:4,scope:'Cancellation only; construct/check/cancel/free; excludes IO and full queue. Explicit free after no further observer calls.',results},null,2));console.log(JSON.stringify(results,null,2));
}finally{await browser.close();await new Promise(resolve=>server.close(resolve));}
