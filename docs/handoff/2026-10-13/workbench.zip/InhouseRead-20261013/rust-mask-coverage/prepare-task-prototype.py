from pathlib import Path
import shutil
source=Path('D:/CodexEvidence/InhouseRead-20261013/rust-length-queue-io-prototype')
out=Path('D:/CodexEvidence/InhouseRead-20261013/rust-length-queue-task-prototype');out.mkdir(exist_ok=True)
for name in ['Cargo.toml','Cargo.lock','factory.mjs','book-length.mjs','legacy.mjs','legacy-shared.mjs','benchmark.mjs','memory.mjs','benchmark-idb.mjs']:
 shutil.copyfile(source/name,out/name)
shutil.copytree(source/'src',out/'src',dirs_exist_ok=True)
p=out/'src/length_queue.rs';s=p.read_text(encoding='utf8')
old=' let task=invoke(c,"task",&[c.value.clone()])?;put(&entry,"task",&task)?;entries.set(&id,&entry);let tail=invoke(c,"swallow",&[task.clone()])?;put(&host(c),"tail",&tail)?;finish(c,&task)'
assert old in s
s=s.replace(old,' put(c,"action",&JsValue::from_f64(2.0))?;Ok(())')
needle='  _=>return Err(js_sys::Error::new("Unknown length queue phase").into())'
assert needle in s
s=s.replace(needle,'  18=>{let entry=get(&c,"entry")?;put(&entry,"task",&value)?;map(&c)?.set(&get(&c,"id")?,&entry);put(host(&c),"tail",&get(&c,"nextTail")?)?;finish(&c,&value)?},\n'+needle)
p.write_bytes(s.encode('utf8'));(out/'length_queue.rs').write_bytes(s.encode('utf8'))
p=out/'factory.mjs';s=p.read_text(encoding='utf8');needle='  const result=core.length_queue_step(context,phases[phase],value)';assert needle in s
s=s.replace(needle,'  context.action=0\n'+needle+'''
  if(context.action===2){
   context.action=0
   const task=host.task(context)
   context.nextTail=task.catch(()=>{})
   return core.length_queue_step(context,18,task)
  }''');p.write_bytes(s.encode('utf8'))
for name in ['benchmark.mjs','memory.mjs','benchmark-idb.mjs']:
 p=out/name;s=p.read_text(encoding='utf8').replace('4521','4525').replace('4522','4526').replace('4524','4527');p.write_bytes(s.encode('utf8'))
print(out)
