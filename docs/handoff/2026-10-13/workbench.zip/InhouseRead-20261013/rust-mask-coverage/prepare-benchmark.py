from pathlib import Path
import shutil
root=Path('C:/Users/migue/Documents/InhouseRead-New')
out=Path(__file__).parent
shutil.copyfile(root/'src/js/cover-color-mask-wasm.js',out/'mask.mjs')
shutil.copyfile(root/'src/wasm/inhouse_read_core.wasm',out/'core.wasm')
shutil.copyfile(root/'tests/helpers/color-mask-cases.mjs',out/'cases.mjs')
s=(root/'tests/unit/helpers/reference-relief-color.js').read_text(encoding='utf8')
c=s[s.index('const LINEAR_RGB ='):s.index('function colorName(')]
assert 'Math.cbrt' in c
(out/'color.mjs').write_text(c+'\nexport {rgbToOklab,rgbOf};\n',encoding='utf8')
