from pathlib import Path
import shutil,re
source=Path('D:/CodexEvidence/InhouseRead-20261012/rust-length-queue-prototype')
out=Path('D:/CodexEvidence/InhouseRead-20261013/rust-length-queue-host-prototype')
out.mkdir(exist_ok=True)
for name in ['Cargo.toml','Cargo.lock','factory.mjs','book-length.mjs','legacy.mjs','legacy-shared.mjs','benchmark.mjs','memory.mjs']:
 shutil.copyfile(source/name,out/name)
shutil.copytree(source/'src',out/'src',dirs_exist_ok=True)
shutil.copytree(source.parent/'rust-core',out.parent/'rust-core',dirs_exist_ok=True)
s=(source/'length_queue.rs').read_text(encoding='utf8')
s=s.replace('fn host(c:&JsValue)->Result<JsValue,JsValue>{get(c,"host")}', 'struct Context{value:JsValue,host:JsValue}\nimpl std::ops::Deref for Context{type Target=JsValue;fn deref(&self)->&JsValue{&self.value}}\nfn host(c:&Context)->&JsValue{&c.host}')
assert 'struct Context' in s,'Actual host signature changed'
for name in ['invoke','callback','finish','wait','map','disposed','active','ready','status','announce','schedule','record','measured']:
 s=s.replace('fn '+name+'(c:&JsValue','fn '+name+'(c:&Context')
s=s.replace('host(c)?','host(c)').replace('host(&c)?','host(&c)')
s=s.replace('pub fn length_queue_active(c:JsValue)->Result<bool,JsValue>{active(&c)}','pub fn length_queue_active(c:JsValue)->Result<bool,JsValue>{let host=get(&c,"host")?;active(&Context{value:c,host})}')
needle='pub fn length_queue_step(c:JsValue,stage:u32,value:JsValue)->Result<JsValue,JsValue>{'
assert needle in s
s=s.replace(needle,needle+'\n let host=get(&c,"host")?;let c=Context{value:c,host};')
(out/'src/length_queue.rs').write_bytes(s.encode('utf8'));(out/'length_queue.rs').write_bytes(s.encode('utf8'))
for name in ['benchmark.mjs','memory.mjs']:
 p=out/name;s=p.read_text(encoding='utf8').replace('4509','4514').replace('4510','4515');p.write_bytes(s.encode('utf8'))
print(out)
