from pathlib import Path
import shutil
source=Path('D:/CodexEvidence/InhouseRead-20261013/rust-length-queue-host-prototype')
out=Path('D:/CodexEvidence/InhouseRead-20261013/rust-length-queue-io-prototype');out.mkdir(exist_ok=True)
for name in ['Cargo.toml','Cargo.lock','factory.mjs','book-length.mjs','legacy.mjs','legacy-shared.mjs','benchmark.mjs','memory.mjs','phase-profile.mjs']:
 shutil.copyfile(source/name,out/name)
shutil.copytree(source/'src',out/'src',dirs_exist_ok=True)
p=out/'src/length_queue.rs';s=p.read_text(encoding='utf8')
start=s.index('   else{put(&c,"latest",&value)?;let file=invoke(')
end=s.index('\n  },',start)
s=s[:start]+'   else{put(&c,"latest",&value)?;return Ok(JsValue::from_f64(1.0))}'+s[end:]
p.write_bytes(s.encode('utf8'));(out/'length_queue.rs').write_bytes(s.encode('utf8'))
p=out/'factory.mjs';s=p.read_text(encoding='utf8')
old=' const step=(context,phase,value)=>core.length_queue_step(context,phases[phase],value)'
assert old in s
new=''' const step=(context,phase,value)=>{
  const result=core.length_queue_step(context,phases[phase],value)
  if(phase==='latest'&&result===1){
   const file=host.file(value)
   let measured
   try{measured=host.measure(file,callback('active',context))}
   catch(error){return core.length_queue_step(context,phases['measure-error'],error)}
   host.wait(context,measured,'measured','measure-error')
  }
  return result
 }'''
p.write_bytes(s.replace(old,new).encode('utf8'))
for name in ['benchmark.mjs','memory.mjs','phase-profile.mjs']:
 p=out/name;s=p.read_text(encoding='utf8').replace('4514','4521').replace('4515','4522').replace('4520','4523');p.write_bytes(s.encode('utf8'))
print(out)
