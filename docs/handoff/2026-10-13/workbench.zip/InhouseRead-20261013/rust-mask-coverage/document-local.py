from pathlib import Path
import json,re,hashlib
root=Path('C:/Users/migue/Documents/InhouseRead-New');out=Path(__file__).parent
units=(out/'unit-full.log').read_text(encoding='utf8');e2e=(out/'e2e-final.log').read_text(encoding='utf8')
assert '6537 passed (6537)' in units,units[-1000:]
assert re.search(r'72 passed \(',e2e),e2e[-1000:]
inventory=json.loads((out/'inventory.json').read_text(encoding='utf8'));assert inventory['rustPercent']==16.38
core=(root/'src/wasm/inhouse_read_core.wasm').read_bytes();ui=(root/'src/wasm/ui/inhouse_read_ui_bg.wasm').read_bytes()
section=f'''# 1.7.234 — cobertura de colores en la misma pasada Rust (local)

Changelog: «Análisis de relieves más rápido».
La clasificación preparada puede obtener el número de píxeles positivos
en su misma pasada Rust. Cuenta después de redondear cada pertenencia a
f32. No recolorea ni cambia máscaras, tolerancias, intensidades o acabados.
Se conserva la API anterior y su resultado 1; el export nuevo devuelve
1 + cobertura y 0 ante rechazo. El puente comprueba su rango por bloque.
Solo el análisis de propuestas pide cobertura; los mapas siguen su ruta
anterior. Un WeakMap entrega el recuento una sola vez antes de exponer la
máscara; conserva los mismos yields cada 4096 píxeles y no retiene imágenes.
La ausencia del export mantiene el recorrido anterior; ante errores se
libera la preparación y se calcula la máscara completa con la ruta original.

96 pruebas focalizadas/4 archivos/11.10 s, y 2 E2E reales del editor/41.8 s
aprobados. Comprueban máscaras y recuentos completos, pausas, alfa, no
finitos, propiedad de buffers, crecimiento de memoria, cancelación,
export ausente, trampas y códigos rechazados. La primera ejecución focal
se interrumpió por el coste del comparador de Buffer; unit-original.log
se conserva. La comparación posterior verifica todos los bytes mediante
Buffer.compare, sin cambiar plazos ni omitir datos.
La batería de {6537} unitarias/{438} archivos pasó. Tanda de 72 E2E pasó
sin reintentos, incluyendo editor, lector, voces, importación, luces y los
contratos originales de cierre de 8 s. No equivale por sí sola a toda la
matriz CI; la CI publicada ejecuta además todos sus shards y pesos reales.

Chromium CPU×4, 9 rondas alternadas, datos sintéticos. Incluye preparación
OKLab JS, asignación, puente, copias, máscaras, cobertura y liberación;
excluye decodificación, clustering, esperas cooperativas, GPU y teléfono.
216×288/10 colores: 50.70→40.40 ms; 512×512/10: 206.40→165.40 ms.
No acredita aceleración global ni lectura/apertura más rápida.
Inventario 7478 Rust/38189 JS = 16.38 %, 99/292 archivos; no es porcentaje
funcional ni incluye dependencias, generados, HTML/CSS o Android Java.
App WASM {len(core)} bytes, SHA256 {hashlib.sha256(core).hexdigest()}.
UI local {len(ui)} bytes, SHA256 {hashlib.sha256(ui).hexdigest()}.
Voz y decoración conservan sus bytes; APK 1.1.15/28 y canales intactos.
Updater fijado al canónico 6621ca1dbb519d171d723f118052e42ef5d5c001,
comprobado remoto, sin editar copias. Publicación y prueba pública de 234
pendientes; no se afirma la corrección del cierre fallido en CI 233.

Prototipo de cola de longitud conservado fuera de producción y sin contar:
35 pruebas de estados/orden/adopción y 1000 completos + 1000 cancelados
con contadores de memoria a cero tras GC. Aunque conserva los resultados,
100 trabajos con I/O simulado CPU×4 cuestan 45 ms frente a 22 ms sin
consultas extra; con 1000 consultas por trabajo, 44.8 frente a 31.6 ms.
Se retiene para optimizar el puente, sin publicar una regresión ni afirmar
que represente el coste del parser o IndexedDB reales.
Evidencia: D:/CodexEvidence/InhouseRead-20261013/rust-mask-coverage.

'''
p=root/'docs/remaining-wip-verification.md';s=p.read_text(encoding='utf8');assert '# 1.7.234' not in s;p.write_bytes((section+s).encode('utf8'))
p=root/'docs/rust-migration.md';s=p.read_text(encoding='utf8');body=s[s.index('Base descargada'):]
header='''# Migración a Rust: implementación y comprobaciones

Entrega local 1.7.234: clasificación y cobertura de colores en una pasada.
Inventario: 7478 Rust/38189 JS, **16.38 %**; no mide funciones terminadas.
6537 unitarias y una tanda de 72 E2E aprobadas sin reintentos.
Máscaras, colores y pausas iguales. Trabajo preparado CPU×4/10 colores:
50.70→40.40 ms; no mide velocidad global ni un teléfono físico.
Publicación y comprobación pública de 234 pendientes. Web 233 y APK real
verificados; CI 233 falla en cierres de 8 s. CI completa 232 aprobada.
Los fallos originales y los prototipos más lentos se conservan.
Detalle de pruebas, límites y publicación: remaining-wip-verification.md.

''';p.write_bytes((header+body).encode('utf8'))
