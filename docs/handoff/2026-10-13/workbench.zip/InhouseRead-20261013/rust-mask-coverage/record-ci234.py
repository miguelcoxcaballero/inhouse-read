from pathlib import Path
import json,base64
root=Path('C:/Users/migue/Documents/InhouseRead-New');out=Path(__file__).parent
status=json.loads((out/'ci234-final.json').read_text(encoding='utf8'));assert status['status']=='completed' and status['conclusion']=='failure'
assert [j['name'] for j in status['jobs'] if j['conclusion']=='failure']==['Reader and bookshelf (2/6)','test']
p=out/'publication.json';d=json.loads(p.read_text());d['ciStatus']='failure';d['ciFailure']='UI2: both native close contracts fail originals and retries; desktop reader-layout evidence is flaky';p.write_bytes(json.dumps(d,indent=2).encode('utf8'))
p=root/'docs/remaining-wip-verification.md';s=p.read_text(encoding='utf8')
s=s.replace('CI 234/38427723850 continúa; no se afirma aprobación global ni corrección\nuniversal del cierre fallido de CI 233.','''CI 234/38427723850 terminó con fallo. UI2/115401419824 conserva los dos
contratos de cierre fallidos, originales y reintentos. Además la captura
desktop paper de reader-controls-layout falló inicialmente al esperar
foliate-view 8 s y pasó al reintentarse; el agregador rechaza ese flaky.
Unitarias, otros cinco shards UI y las cuatro tandas de voces reales
pasaron. El agregador/test 115418486958 falló como corresponde.
Originales completos: ci234-ui2-original.log y ci234-ui2-original-artifact,
con reporte, capturas y traces. No se afirma aprobación global ni
corrección universal del cierre fallido de CI 233.''')
p.write_bytes(s.encode('utf8'))
p=root/'docs/rust-migration.md';s=p.read_text(encoding='utf8').replace('3 perfil y audio Android 2×. CI 234 en curso; CI 233 falla en cierres de\n8 s. CI completa 232 aprobada.','3 perfil y audio Android 2×. CI 234 falla en cierres de 8 s y una captura\ndel lector inestable; todos los pesos reales pasaron. CI 232 aprobada.');p.write_bytes(s.encode('utf8'))
artifact=out/'ci234-ui2-original-artifact';report=json.loads((artifact/'playwright-report/results.json').read_text(encoding='utf8'))
def walk(suites):
 for suite in suites:
  yield from suite.get('specs',[])
  yield from walk(suite.get('suites',[]))
facts=[]
for spec in walk(report['suites']):
 if 'shelf-return-contract' not in spec['file']:continue
 for test in spec['tests']:
  for result in test['results']:
   for a in result.get('attachments',[]):
    if a['name'] not in ['native-shelf-return-contract','native-legacy-shelf-return-contract']:continue
    if 'body' in a:data=json.loads(base64.b64decode(a['body']))
    else:
     candidates=list(artifact.rglob(Path(a['path']).name));assert candidates
     data=json.loads(candidates[0].read_text(encoding='utf8'))
    facts.append({'file':spec['file'],'status':result['status'],'retry':result['retry'],'clickedAt':data.get('clickedAt'),'endedAt':data.get('endedAt'),'phases':data.get('phases'),'final':data.get('final')})
(out/'ci234-close-facts.json').write_bytes(json.dumps(facts,indent=2).encode('utf8'))
print(json.dumps([{'file':r['file'],'retry':r['retry'],'elapsed':r['endedAt']-r['clickedAt'] if r['endedAt'] else None} for r in facts]))
