from pathlib import Path
import shutil
root=Path('C:/Users/migue/Documents/InhouseRead-New');out=Path('D:/CodexEvidence/InhouseRead-20261013/rust-cover-seed-prototype');out.mkdir(exist_ok=True)
shutil.copytree(root/'rust-core/src',out/'src',dirs_exist_ok=True)
for name in ['Cargo.toml','Cargo.lock']:shutil.copyfile(root/'rust-core'/name,out/name)
p=out/'src/lib.rs';s=p.read_text(encoding='utf8');p.write_bytes((s+'\n#[cfg(feature="app")]\nmod cover_seed;\n').encode('utf8'))
print(out)
