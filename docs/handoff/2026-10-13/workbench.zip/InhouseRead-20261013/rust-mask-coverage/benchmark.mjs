import {createServer} from 'node:http';
import {readFile,writeFile} from 'node:fs/promises';
import {chromium} from 'file:///C:/Users/migue/Documents/InhouseRead-New/node_modules/playwright/index.mjs';
const server=createServer(async(req,res)=>{try{const name=req.url==='/'?'index.html':req.url.slice(1);if(!['index.html','mask.mjs','cases.mjs','color.mjs','core.wasm'].includes(name)){res.writeHead(404);return res.end();}res.setHeader('Content-Type',name==='index.html'?'text/html':name.endsWith('wasm')?'application/wasm':'text/javascript');res.end(name==='index.html'?'<title>Mask coverage</title>':await readFile(new URL(name,import.meta.url)));}catch(e){res.writeHead(500);res.end(String(e));}});
await new Promise(resolve=>server.listen(4512,'127.0.0.1',resolve));const browser=await chromium.launch({headless:true});
try{
 const page=await browser.newPage();await page.goto('http://127.0.0.1:4512/');await(await page.context().newCDPSession(page)).send('Emulation.setCPUThrottlingRate',{rate:4});
 const results=await page.evaluate(async()=>{
  const {prepareColorMaskJob,countPreparedMaskPixels}=await import('./mask.mjs'),{rgbToOklab,rgbOf}=await import('./color.mjs'),{makeColorMaskImage,colorMaskPalette}=await import('./cases.mjs');
  const core=(await WebAssembly.instantiateStreaming(fetch('./core.wasm'))).instance.exports;
  const drain=task=>{let s;do{s=task.next();}while(!s.done);return s.value;},median=v=>[...v].sort((a,b)=>a-b)[4],results=[];
  for(const [width,height,kind] of [[128,128,'panels'],[216,288,'panels'],[216,288,'noise'],[341,512,'panels'],[512,512,'noise']])for(const layers of [3,10]){
   const image=makeColorMaskImage({width,height,kind}),targets=colorMaskPalette.slice(0,layers).map(c=>rgbToOklab(...rgbOf(c)));
   const run=counted=>{const job=drain(prepareColorMaskJob(core,image,rgbToOklab));let sum=0;try{for(const target of targets){const mask=drain(job.mask(target,6,counted));sum+=drain(countPreparedMaskPixels(mask));}}finally{job.dispose();}return sum;};
   const expected=run(false);if(run(true)!==expected)throw Error('Coverage mismatch');
   for(let i=0;i<4;i++){run(false);run(true);}const js=[],rust=[];
   for(let r=0;r<9;r++)for(const counted of r%2?[true,false]:[false,true]){const at=performance.now();if(run(counted)!==expected)throw Error('Changed count');(counted?rust:js).push(performance.now()-at);}
   results.push({width,height,kind,layers,includesPreparation:true,js,rust,jsMedian:median(js),rustMedian:median(rust)});
  }return results;
 });
 await writeFile(new URL('benchmark.json',import.meta.url),JSON.stringify({cpuThrottle:4,scope:'Synthetic browser pixels, whole prepared job with JS OKLab, allocation, f32 copies, coverage, generator pauses and free. No image decode, actual cooperative waits, clustering, GPU or phone.',results},null,2));console.log(JSON.stringify(results,null,2));
}finally{await browser.close();await new Promise(resolve=>server.close(resolve));}
