from pathlib import Path
root=Path('C:/Users/migue/Documents/InhouseRead-New')
out=Path(__file__).parent
old=Path('D:/CodexEvidence/InhouseRead-20261012/rust-studio-scan-prototype/run-final.ps1').read_text(encoding='utf8')
command=old[old.index("$env:PLAYWRIGHT_SUITE='all'"):]
command=command.replace('tests/e2e/shelf-light-effect.spec.mjs --workers', 'tests/e2e/shelf-light-effect.spec.mjs tests/e2e/rust-relief-editor.spec.mjs --workers')
prefix="$ErrorActionPreference='Stop'\n$taskEvidence='"+str(out).replace('\\','/')+"'\n"
prefix+="if(-not ((Get-Content \"$taskEvidence/unit-full.log\" -Raw).Contains('6537 passed (6537)'))){throw 'Final units not complete'}\n"
(out/'run-regressions.ps1').write_bytes((prefix+command).encode('utf8'))
