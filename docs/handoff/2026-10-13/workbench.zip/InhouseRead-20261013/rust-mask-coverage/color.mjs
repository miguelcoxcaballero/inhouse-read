const LINEAR_RGB = Float64Array.from({ length:256 }, (_, byte) => {
  const s = byte / 255;
  return s <= .04045 ? s / 12.92 : ((s + .055) / 1.055) ** 2.4;
});
function rgbToOklab(r, g, b) {
  r = LINEAR_RGB[r]; g = LINEAR_RGB[g]; b = LINEAR_RGB[b];
  const l = Math.cbrt(.4122214708 * r + .5363325363 * g + .0514459929 * b);
  const m = Math.cbrt(.2119034982 * r + .6806995451 * g + .1073969566 * b);
  const s = Math.cbrt(.0883024619 * r + .2817188376 * g + .6299787005 * b);
  return [100 * (.2104542553 * l + .7936177850 * m - .0040720468 * s),
    100 * (1.9779984951 * l - 2.4285922050 * m + .4505937099 * s),
    100 * (.0259040371 * l + .7827717662 * m - .8086757660 * s)];
}
const distance2 = (a, b) => (a[0]-b[0]) ** 2 + (a[1]-b[1]) ** 2 + (a[2]-b[2]) ** 2;
const hexOf = rgb => '#' + rgb.map(byte => byte.toString(16).padStart(2, '0')).join('');
const rgbOf = hex => [1, 3, 5].map(at => parseInt(hex.slice(at, at + 2), 16));

export {rgbToOklab,rgbOf};
