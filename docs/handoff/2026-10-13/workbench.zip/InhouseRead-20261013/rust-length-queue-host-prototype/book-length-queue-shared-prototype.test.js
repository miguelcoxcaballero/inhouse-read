import {beforeAll,afterEach,it,expect,vi} from 'vitest'
import {readFileSync} from 'node:fs'
import * as ui from 'D:/CodexEvidence/InhouseRead-20261013/rust-length-queue-host-prototype/pkg/inhouse_read_ui.js'
import {createNativeLengthQueue} from 'D:/CodexEvidence/InhouseRead-20261013/rust-length-queue-host-prototype/factory.mjs'
import {createBookLengthQueue as sharedLegacy} from 'D:/CodexEvidence/InhouseRead-20261013/rust-length-queue-host-prototype/legacy-shared.mjs'
import {isBookLengthReady,newContentRevision} from '../../src/js/book-length-queue.js'
import {hasCompleteWordCount,completeWordCount} from '../../src/js/book-length.js'
const helpers={ready:isBookLengthReady,revision:newContentRevision,hasComplete:hasCompleteWordCount,complete:completeWordCount},queues=[]
beforeAll(()=>ui.initSync({module:readFileSync('D:/CodexEvidence/InhouseRead-20261013/rust-length-queue-host-prototype/pkg/inhouse_read_ui_bg.wasm')}))
afterEach(()=>{for(const q of queues.splice(0))q.dispose();expect(ui.ui_live_handles()).toBe(0)})
const book=id=>({id,name:id+'.epub',contentRevision:id,content:new Blob(['book'])})
const tick=async()=>{for(let i=0;i<12;i++)await Promise.resolve()}
const store=records=>({get:async id=>records.get(id),patch:async(id,fields,options)=>{const current=records.get(id);if(!options.ifCurrent(current))return null;const next={...current,...fields};records.set(id,next);return next}})
const setup=(library,options)=>{const legacy=sharedLegacy(library,options);queues.push(legacy);return {legacy,adopt(){const shared=legacy.transferState(),native=createNativeLengthQueue(library,shared.options,ui,helpers,shared);queues.push(native);return native}}}
it('adopts a running legacy count without parsing it twice or overlapping its trailing native job',async()=>{
 const records=new Map([['first',book('first')],['second',book('second')]]),library=store(records);let finish;const order=[]
 const measureFile=vi.fn(file=>{order.push(file.name);return measureFile.mock.calls.length===1?new Promise(resolve=>{finish=resolve}):Promise.resolve(completeWordCount(20))})
 const {legacy,adopt}=setup(library,{measureFile}),old=legacy.ensure(records.get('first'));await tick();expect(order).toEqual(['first.epub'])
 const native=adopt(),joined=native.ensure(records.get('first')),next=native.ensure(records.get('second'));await tick();expect(order).toEqual(['first.epub'])
 finish(completeWordCount(10));expect((await old).wordCount).toBe(10);expect((await joined).wordCount).toBe(10);expect((await next).wordCount).toBe(20);expect(order).toEqual(['first.epub','second.epub'])
})
it('native disposal reaches a legacy lookup that started before adoption',async()=>{
 const record=book('first');let finish;const measureFile=vi.fn(),library={get:()=>new Promise(resolve=>{finish=resolve})},pair=setup(library,{measureFile}),old=pair.legacy.ensure('first')
 pair.adopt().dispose();finish(record);expect(await old).toBe(record);expect(measureFile).not.toHaveBeenCalled()
})
it('legacy disposal cancels the captured native guard and prevents a commit',async()=>{
 const records=new Map([['first',book('first')]]),library=store(records);let finish,isActive
 const pair=setup(library,{measureFile:(_,options)=>{isActive=options.isActive;return new Promise(resolve=>{finish=resolve})}}),native=pair.adopt(),task=native.ensure(records.get('first'))
 await tick();expect(isActive()).toBe(true);pair.legacy.dispose();expect(isActive()).toBe(false);finish(completeWordCount(5));expect(await task).toBeNull();expect(records.get('first').wordCount).toBeUndefined()
})
it('a legacy cancellation reaches an already measuring native entry',async()=>{
 const records=new Map([['first',book('first')]]),library=store(records);let finish,isActive
 const pair=setup(library,{measureFile:(_,options)=>{isActive=options.isActive;return new Promise(resolve=>{finish=resolve})}}),native=pair.adopt(),task=native.ensure(records.get('first'))
 await tick();pair.legacy.cancel('first');expect(isActive()).toBe(false);finish(completeWordCount(5));expect(await task).toBeNull()
})
