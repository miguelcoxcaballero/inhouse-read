from pathlib import Path
root=Path('C:/Users/migue/Documents/InhouseRead-New');old=Path('D:/CodexEvidence/InhouseRead-20261012/rust-length-queue-prototype');out=Path(__file__).parent
for name in ['book-length-queue-order-prototype.test.js','book-length-queue-rust-prototype.test.js','book-length-queue-shared-prototype.test.js']:
 s=(old/name).read_text(encoding='utf8').replace(str(old).replace('\\','/'),str(out).replace('\\','/'))
 p=root/'tests/unit'/name;assert not p.exists();p.write_bytes(s.encode('utf8'))
