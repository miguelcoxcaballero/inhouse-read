from pathlib import Path
out=Path(__file__).parent
s=(out/'benchmark.mjs').read_text(encoding='utf8').replace('4514','4520')
s=s.replace('  const results=[]','''  const results=[],phases={};
  const observed={...ui,length_queue_step(...args){const phase=args[1],at=performance.now();try{return ui.length_queue_step(...args)}finally{const entry=phases[phase]||=( {calls:0,ms:0});entry.calls++;entry.ms+=performance.now()-at;}}};''')
s=s.replace('createNativeLengthQueue(library,options,ui,helpers)','createNativeLengthQueue(library,options,observed,helpers)')
s=s.replace('for(const checks of [0,20,1000])','for(const checks of [0])')
start=s.index('   for(let i=0;i<4;i++)');end=s.index('  return results',start)
s=s[:start]+'''   await run(false);await run(true);for(const key of Object.keys(phases))delete phases[key];
   const legacyMs=await run(false),rustMs=await run(true);results.push({jobs:100,legacyMs,rustMs,phases});
  }
'''+s[end:]
s=s.replace("new URL('./benchmark.json'", "new URL('./phase-profile.json'")
s=s.replace("console.log(JSON.stringify(results.map(({jobs,activeChecksPerJob,jsMedian,rustMedian})=>({jobs,activeChecksPerJob,jsMedian,rustMedian}))))", "console.log(JSON.stringify(results))")
(out/'phase-profile.mjs').write_bytes(s.encode('utf8'))
