from pathlib import Path
out=Path(__file__).parent
s=(out/'benchmark.mjs').read_text(encoding='utf8')
s=s.replace('4514','4516')
s=s.replace("const ui=await import('./pkg/inhouse_read_ui.js');",'''const imports={},observe=table=>{for(const [module,fields] of Object.entries(table||{}))for(const [name,fn] of Object.entries(fields))if(typeof fn==='function'){fields[name]=function(...args){const key=module+'.'+name;imports[key]=(imports[key]||0)+1;return Reflect.apply(fn,this,args)}}};
  for(const name of ['instantiate','instantiateStreaming']){const original=WebAssembly[name];WebAssembly[name]=function(source,table){observe(table);return Reflect.apply(original,WebAssembly,[source,table])}}
  const ui=await import('./pkg/inhouse_read_ui.js');''')
s=s.replace('for(const checks of [0,20,1000])','for(const checks of [0])')
start=s.index('   for(let i=0;i<4;i++)')
end=s.index('  return results',start)
s=s[:start]+'''   for(const name of Object.keys(imports))imports[name]=0;
   await run(true);results.push({jobs:100,imports:Object.entries(imports).filter(([,count])=>count).sort((a,b)=>b[1]-a[1])});
  }
'''+s[end:]
s=s.replace("new URL('./benchmark.json'", "new URL('./import-profile.json'")
s=s.replace("console.log(JSON.stringify(results.map(({jobs,activeChecksPerJob,jsMedian,rustMedian})=>({jobs,activeChecksPerJob,jsMedian,rustMedian}))))", "console.log(JSON.stringify(results))")
(out/'import-profile.mjs').write_bytes(s.encode('utf8'))
