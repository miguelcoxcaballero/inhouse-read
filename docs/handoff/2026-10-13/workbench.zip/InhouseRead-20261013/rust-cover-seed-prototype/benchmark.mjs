import {createServer} from 'node:http';import {readFile,writeFile} from 'node:fs/promises';
import {chromium} from 'file:///C:/Users/migue/Documents/InhouseRead-New/node_modules/playwright/index.mjs';
const server=createServer(async(req,res)=>{try{const name=req.url==='/'?'index.html':req.url.slice(1);if(!['index.html','seed.mjs','core.wasm'].includes(name)){res.writeHead(404);return res.end();}res.setHeader('Content-Type',name==='index.html'?'text/html':name.endsWith('wasm')?'application/wasm':'text/javascript');res.end(name==='index.html'?'<title>Prepared cover seed</title>':await readFile(new URL(name,import.meta.url)));}catch(e){res.writeHead(500);res.end(String(e));}});
await new Promise(resolve=>server.listen(4528,'127.0.0.1',resolve));const browser=await chromium.launch({headless:true});
try{const page=await browser.newPage();await page.goto('http://127.0.0.1:4528/');await(await page.context().newCDPSession(page)).send('Emulation.setCPUThrottlingRate',{rate:4});
 const results=await page.evaluate(async()=>{const {seedOf}=await import('./seed.mjs'),core=(await WebAssembly.instantiateStreaming(fetch('./core.wasm'))).instance.exports,results=[];
 for(const [width,height] of [[128,128],[216,288],[341,512],[512,512]]){
  const data=Uint8Array.from({length:width*height*4},(_,i)=>i*17&255),image={data,width,height},n=data.length/8,p=core.alloc_f64(n);new Uint8Array(core.memory.buffer,p,data.length).set(data);
  try{const expected=seedOf(image),run=native=>{let hash=0;for(let i=0;i<100;i++){hash=native?core.relief_cover_seed(p,width,height):seedOf(image);if(hash!==expected)throw Error('Seed mismatch');}return hash;};for(let i=0;i<8;i++){run(false);run(true);}const js=[],rust=[];
   for(let r=0;r<9;r++)for(const native of r%2?[true,false]:[false,true]){const at=performance.now();run(native);(native?rust:js).push((performance.now()-at)/100);}
   const median=v=>[...v].sort((a,b)=>a-b)[4];results.push({width,height,js,rust,jsMedian:median(js),rustMedian:median(rust)});
  }finally{core.free_f64(p,n);}
 }return results;});await writeFile(new URL('benchmark.json',import.meta.url),JSON.stringify({cpuThrottle:4,scope:'Seed operation and bridge only; uses RGBA already copied by the palette. Excludes unchanged palette copy/allocation, palette classification, image decode, UI, GPU and phone.',results},null,2));console.log(JSON.stringify(results));
}finally{await browser.close();await new Promise(resolve=>server.close(resolve));}
