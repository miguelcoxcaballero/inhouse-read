import {readFile,writeFile} from 'node:fs/promises';
import assert from 'node:assert/strict';
import {seedOf} from './seed.mjs';
const bytes=await readFile(new URL('core.wasm',import.meta.url)),module=await WebAssembly.compile(bytes);assert.equal(WebAssembly.Module.imports(module).length,0);
const core=(await WebAssembly.instantiate(module)).exports;assert.equal(typeof core.relief_cover_seed,'function');
let cases=0;
for(let width=1;width<=51;width++)for(let height=1;height<=75;height++){
 const data=new Uint8Array(width*height*4);for(let i=0;i<data.length;i++)data[i]=(Math.imul(i+width*751+height*17,48271)>>>7)&255;
 const n=Math.ceil(data.length/8)+1,p=core.alloc_f64(n);assert.ok(p);
 try{new Uint8Array(core.memory.buffer,p+1,data.length).set(data);assert.equal(core.relief_cover_seed(p+1,width,height),seedOf({data,width,height}));assert.deepEqual(new Uint8Array(core.memory.buffer,p+1,data.length),data);cases++;}finally{core.free_f64(p,n);}
}
for(const [width,height] of [[171,256],[216,288],[341,512],[512,512],[262144,1],[1,262144]]){
 const data=new Uint8Array(width*height*4);for(let i=0;i<data.length;i++)data[i]=i*17&255;
 const n=data.length/8,p=core.alloc_f64(n);try{new Uint8Array(core.memory.buffer,p,data.length).set(data);assert.equal(core.relief_cover_seed(p,width,height),seedOf({data,width,height}));cases++;}finally{core.free_f64(p,n);}
}
for(const args of [[0,1,1],[1,0,1],[1,1,0],[1,513,512],[1,0xffffffff,0xffffffff]])assert.equal(core.relief_cover_seed(...args),-1);
const result={cases,malformed:5,status:'passed',unaligned:true};await writeFile(new URL('verify.json',import.meta.url),JSON.stringify(result,null,2));console.log(JSON.stringify(result));
