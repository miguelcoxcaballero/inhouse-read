import sys,time,json
from pathlib import Path
sys.path.insert(0,'C:/Users/migue/Documents/InhouseRead-New/.github/scripts')
from verify_android_app import run,open_fixture_document,capture,node_text
from verify_android_background import ui_action,wait_state,logs,freeze_full_logcat
PACKAGE='com.inhousesoftware.read'
result={'web':'1.7.235','apkVersion':'1.1.15','versionCode':28,'cases':[]}
def played_seconds(session):
 _,states,_,_=logs();epochs={}
 for state in states:
  if state.get('session')==session:
   epochs[state['epoch']]=max(epochs.get(state['epoch'],0),state.get('playedSeconds',0))
 return sum(epochs.values())
try:
 run('adb','shell','am','force-stop',PACKAGE)
 run('adb','shell','am','start','-n',PACKAGE+'/.MainActivity')
 # Allow the untapped-launch freshness check before opening the account menu.
 time.sleep(4)
 for attempt in range(8):
  root=capture(Path('native-version.png'),Path('native-version.xml'));text=node_text(root)
  if 'v1.7.235' in text: break
  assert not __import__('re').search(r'Inhouse Read.*v1\.7\.\d+',text),text
  ui_action('version-account',r'^Cuenta (y ajustes|de Google)',45,require_button=True)
  time.sleep(1)
 else: raise AssertionError('Version menu not ready: '+text)
 result['visibleVersion']='1.7.235'
 ui_action('version-close',r'^Cuenta (y ajustes|de Google)',require_button=True)
 open_fixture_document('audiobook')
 run('adb','logcat','-c')
 pid=run('adb','shell','pidof',PACKAGE).stdout.strip();result['pid']=pid
 ui_action('audio',r'^Escuchar el libro$')
 for rate,pattern in [(2,r'^2.$')]:
  ui_action('rate-'+str(rate),pattern)
  ui_action('play-'+str(rate),r'^(Reproducir|Continuar)$')
  first=wait_state(lambda s,e,p:s['active'] and s['sampleRate']>0 and played_seconds(s['session'])>10 and sum(x.get('type')=='done' and x.get('session')==s['session'] for x in e)>=3,'audible-'+str(rate),120)
  raw,states,events,progress=logs();current=run('adb','shell','pidof',PACKAGE).stdout.strip();assert current==pid,(pid,current)
  session=first['session'];ev=[e for e in events if e.get('session')==session]
  assert not [e for e in ev if e.get('type')=='error'],ev
  result['cases'].append({'rate':rate,'session':session,'sampleRate':first['sampleRate'],'playedFrames':first['playedFrames'],'cumulativePlayedSeconds':played_seconds(session),'starts':sum(e.get('type')=='start' for e in ev),'dones':sum(e.get('type')=='done' for e in ev),'sameProcess':True,'events':ev})
  capture(Path('native-playing-'+str(rate)+'.png'),Path('native-playing-'+str(rate)+'.xml'))
  ui_action('stop-'+str(rate),r'^Detener$')
 raw=run('adb','logcat','-d').stdout;Path('native-ui235-full-logcat.txt').write_text(raw,encoding='utf-8')
 assert 'FATAL EXCEPTION' not in raw
 result['status']='passed'
except Exception as e:
 result['status']='failed';result['error']=str(e);freeze_full_logcat('native-ui235-failed');raise
finally:
 Path('native-ui235.json').write_text(json.dumps(result,indent=2),encoding='utf-8');print(json.dumps(result),flush=True)









