from pathlib import Path
import hashlib
root=Path('C:/Users/migue/Documents/InhouseRead-New');source=Path('D:/CodexEvidence/InhouseRead-20261013/rust-mask-coverage');out=Path(__file__).parent
s=(source/'run-regressions.ps1').read_text(encoding='utf8').replace(str(source).replace('\\','/'),str(out).replace('\\','/')).replace('6537 passed (6537)','6548 passed (6548)');(out/'run-regressions.ps1').write_bytes(s.encode('utf8'))
sha=hashlib.sha256((root/'src/wasm/inhouse_read_core.wasm').read_bytes()).hexdigest()
s=(source/'verify-public-234.mjs').read_text(encoding='utf8').replace('1.7.234','1.7.235').replace('959706ea8ba4df391b8ef0b90c4be20f1e22d43fc263c993cced341b60517652',sha)
s=s.replace("'relief_color_mask_count'])check('compiled", "'relief_color_mask_count','relief_cover_seed'])check('compiled")
(out/'verify-public-235.mjs').write_bytes(s.encode('utf8'))
s=(source/'native-ui234.py').read_text(encoding='utf8').replace('1.7.234','1.7.235').replace('native-ui234','native-ui235');(out/'native-ui235.py').write_bytes(s.encode('utf8'))
