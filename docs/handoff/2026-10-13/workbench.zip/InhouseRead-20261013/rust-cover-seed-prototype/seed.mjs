export function seedOf(image){
 const {data,width,height}=image;let state=2166136261;
 const stepX=Math.max(1,Math.floor(width/24)),stepY=Math.max(1,Math.floor(height/36));
 for(let y=0;y<height;y+=stepY)for(let x=0;x<width;x+=stepX){const at=(y*width+x)*4;state=Math.imul(state^(data[at]>>4),16777619);state=Math.imul(state^(data[at+1]>>4),16777619);state=Math.imul(state^(data[at+2]>>4),16777619);}
 return state>>>0;
}
