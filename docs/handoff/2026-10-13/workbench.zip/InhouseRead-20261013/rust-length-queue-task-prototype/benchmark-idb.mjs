import {createServer} from 'node:http'
import {readFile,writeFile} from 'node:fs/promises'
import {chromium} from 'file:///C:/Users/migue/Documents/InhouseRead-New/node_modules/playwright/index.mjs'
const server=createServer(async(req,res)=>{try{const name=req.url==='/'?'index.html':req.url.slice(1);if(!['index.html','factory.mjs','legacy.mjs','book-length.mjs','pkg/inhouse_read_ui.js','pkg/inhouse_read_ui_bg.wasm'].includes(name)){res.writeHead(404);return res.end()}if(name==='index.html'){res.setHeader('Content-Type','text/html');return res.end('<!doctype html><title>Length queue benchmark</title>')}res.setHeader('Content-Type',name.endsWith('wasm')?'application/wasm':'text/javascript');res.end(await readFile(new URL(name,import.meta.url)))}catch(error){res.writeHead(500);res.end(String(error))}})
await new Promise(resolve=>server.listen(4527,'127.0.0.1',resolve));const browser=await chromium.launch({headless:true})
try{
 const page=await browser.newPage();await page.goto('http://127.0.0.1:4527/');await(await page.context().newCDPSession(page)).send('Emulation.setCPUThrottlingRate',{rate:4})
 const results=await page.evaluate(async()=>{
  const ui=await import('./pkg/inhouse_read_ui.js');await ui.default();ui.length_queue_prepare();const fixedKeys=ui.ui_live_handles()
  const {createNativeLengthQueue}=await import('./factory.mjs'),legacy=await import('./legacy.mjs'),length=await import('./book-length.mjs')
  const helpers={ready:legacy.isBookLengthReady,revision:legacy.newContentRevision,hasComplete:length.hasCompleteWordCount,complete:length.completeWordCount}
  const db=await new Promise((resolve,reject)=>{const r=indexedDB.open('length-queue-benchmark',1);r.onupgradeneeded=()=>r.result.createObjectStore('books',{keyPath:'id'});r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error)});
  const read=id=>new Promise((resolve,reject)=>{const r=db.transaction('books').objectStore('books').get(id);r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error)});
  const patch=(id,fields,options)=>new Promise((resolve,reject)=>{const tx=db.transaction('books','readwrite'),store=tx.objectStore('books'),r=store.get(id);let saved=null;r.onsuccess=()=>{const current=r.result;if(options.ifCurrent(current)){saved={...current,...fields};store.put(saved)}};tx.oncomplete=()=>resolve(saved);tx.onerror=tx.onabort=()=>reject(tx.error)});
  const results=[]
  for(const checks of [4000,20000]){
   const run=async native=>{
    const records=new Map(Array.from({length:3},(_,i)=>['book:'+i,{id:'book:'+i,name:'book.epub',contentRevision:'rev:'+i,content:new Blob(['word '.repeat(checks)],{type:'text/plain'})}]))
    await new Promise((resolve,reject)=>{const tx=db.transaction('books','readwrite'),store=tx.objectStore('books');store.clear();for(const record of records.values())store.put(record);tx.oncomplete=resolve;tx.onerror=()=>reject(tx.error)});
    let count=0;const library={get:read,patch};
    const options={measureFile:async(file,{isActive})=>{const words=await length.countTextWords(await file.text(),{language:'en',isActive});count++;return length.completeWordCount(words)}};
    const queue=native?createNativeLengthQueue(library,options,ui,helpers):legacy.createBookLengthQueue(library,options)
    const start=performance.now();const values=await Promise.all([...records.values()].map(book=>queue.ensure(book)));const time=performance.now()-start
    if(count!==3||values.some(value=>value.wordCount!==checks))throw Error('Parity failed');queue.dispose();if(ui.ui_live_handles()!==fixedKeys)throw Error('Retained handles: '+ui.ui_live_handles()+' instead of '+fixedKeys);return time
   }
   for(let i=0;i<2;i++){await run(false);await run(true)}
   const js=[],rust=[];for(let i=0;i<9;i++){if(i%2){rust.push(await run(true));js.push(await run(false))}else{js.push(await run(false));rust.push(await run(true))}}
   const median=a=>[...a].sort((a,b)=>a-b)[4];results.push({jobs:3,wordsPerBook:checks,js,rust,jsMedian:median(js),rustMedian:median(rust)})
  }
  return results
 })
 await writeFile(new URL('./benchmark-idb.json',import.meta.url),JSON.stringify({cpuThrottle:4,includes:'3 jobs with actual IndexedDB transactions and Blob/File bytes, Intl word counter with original yields and cancellation; excludes PDF/EPUB extraction, whole UI and actual phone',results},null,2));console.log(JSON.stringify(results))
}finally{await browser.close();await new Promise(resolve=>server.close(resolve))}
