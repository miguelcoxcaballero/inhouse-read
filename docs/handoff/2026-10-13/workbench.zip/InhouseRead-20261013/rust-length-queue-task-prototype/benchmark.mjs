import {createServer} from 'node:http'
import {readFile,writeFile} from 'node:fs/promises'
import {chromium} from 'file:///C:/Users/migue/Documents/InhouseRead-New/node_modules/playwright/index.mjs'
const server=createServer(async(req,res)=>{try{const name=req.url==='/'?'index.html':req.url.slice(1);if(!['index.html','factory.mjs','legacy.mjs','book-length.mjs','pkg/inhouse_read_ui.js','pkg/inhouse_read_ui_bg.wasm'].includes(name)){res.writeHead(404);return res.end()}if(name==='index.html'){res.setHeader('Content-Type','text/html');return res.end('<!doctype html><title>Length queue benchmark</title>')}res.setHeader('Content-Type',name.endsWith('wasm')?'application/wasm':'text/javascript');res.end(await readFile(new URL(name,import.meta.url)))}catch(error){res.writeHead(500);res.end(String(error))}})
await new Promise(resolve=>server.listen(4525,'127.0.0.1',resolve));const browser=await chromium.launch({headless:true})
try{
 const page=await browser.newPage();await page.goto('http://127.0.0.1:4525/');await(await page.context().newCDPSession(page)).send('Emulation.setCPUThrottlingRate',{rate:4})
 const results=await page.evaluate(async()=>{
  const ui=await import('./pkg/inhouse_read_ui.js');await ui.default();ui.length_queue_prepare();const fixedKeys=ui.ui_live_handles()
  const {createNativeLengthQueue}=await import('./factory.mjs'),legacy=await import('./legacy.mjs'),length=await import('./book-length.mjs')
  const helpers={ready:legacy.isBookLengthReady,revision:legacy.newContentRevision,hasComplete:length.hasCompleteWordCount,complete:length.completeWordCount}
  const results=[]
  for(const checks of [0,20,1000]){
   const run=async native=>{
    const records=new Map(Array.from({length:100},(_,i)=>['book:'+i,{id:'book:'+i,name:'book.epub',contentRevision:'rev:'+i,content:new Blob(['book'])}]))
    let count=0;const library={get:async id=>records.get(id),patch:async(id,fields,options)=>{const current=records.get(id);if(!options.ifCurrent(current))return null;const next={...current,...fields};records.set(id,next);return next}}
    const options={measureFile:async(file,{isActive})=>{for(let i=0;i<checks;i++)if(!isActive())throw Error('Inactive');count++;return length.completeWordCount(1000)}}
    const queue=native?createNativeLengthQueue(library,options,ui,helpers):legacy.createBookLengthQueue(library,options)
    const start=performance.now();const values=await Promise.all([...records.values()].map(book=>queue.ensure(book)));const time=performance.now()-start
    if(count!==100||values.some(value=>value.wordCount!==1000))throw Error('Parity failed');queue.dispose();if(ui.ui_live_handles()!==fixedKeys)throw Error('Retained handles: '+ui.ui_live_handles()+' instead of '+fixedKeys);return time
   }
   for(let i=0;i<4;i++){await run(false);await run(true)}
   const js=[],rust=[];for(let i=0;i<9;i++){if(i%2){rust.push(await run(true));js.push(await run(false))}else{js.push(await run(false));rust.push(await run(true))}}
   const median=a=>[...a].sort((a,b)=>a-b)[4];results.push({jobs:100,activeChecksPerJob:checks,js,rust,jsMedian:median(js),rustMedian:median(rust)})
  }
  return results
 })
 await writeFile(new URL('./benchmark.json',import.meta.url),JSON.stringify({cpuThrottle:4,includes:'100 jobs, promise scheduling, file construction, guards and callbacks; fake storage, excludes parser and database IO',results},null,2));console.log(JSON.stringify(results.map(({jobs,activeChecksPerJob,jsMedian,rustMedian})=>({jobs,activeChecksPerJob,jsMedian,rustMedian}))))
}finally{await browser.close();await new Promise(resolve=>server.close(resolve))}
