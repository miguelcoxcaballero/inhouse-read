// JS retains browser IO and traced promise captures; Rust makes job decisions.
export function createNativeLengthQueue(library,options,core,helpers,shared){
 const {ready,hasComplete,complete,revision,measureDefault}=helpers
 const {measureFile=measureDefault,onChange=()=>{},onError=()=>{}}=options||{}
 const host=shared||{entries:new Map(),tail:Promise.resolve(),disposed:false}
 const lifetime=new core.RustLengthLifetime(host.disposed),descriptor=Object.getOwnPropertyDescriptor(host,'disposed')
 let disposed=host.disposed
 Object.defineProperty(host,'disposed',{configurable:true,enumerable:true,
  get:()=>descriptor.get?descriptor.get.call(host):disposed,
  set:value=>{if(descriptor.set)descriptor.set.call(host,value);else disposed=value;lifetime.setDisposed(value)}})
 const phases={'ensure':0,'record':1,'patched':2,'revised':3,'new-revision-current':4,'active':5,'job':6,'latest':7,'measure-error':8,'measured':9,'commit-current':10,'saved':11,'job-error':12,'reject':13,'geometry':14,'cancel':15,'dispose':16,'retry':17}
 const step=(context,phase,value)=>{
  const result=core.length_queue_step(context,phases[phase],value)
  if(phase==='latest'&&result===1){
   const file=host.file(value)
   let measured
   try{measured=host.measure(file,callback('active',context))}
   catch(error){return core.length_queue_step(context,phases['measure-error'],error)}
   host.wait(context,measured,'measured','measure-error')
  }
  return result
 }
 const callback=(phase,context)=>phase==='active'?()=>context.entry.nativeGuard.active():value=>step(context,phase,value)
 const reaction=(phase,context)=>value=>{try{step(context,phase,value)}catch(error){context.reject(error)}}
 host.callback=callback
 host.wait=(context,promise,ok,error)=>{Promise.resolve(promise).then(reaction(ok,context),reaction(error,context))}
 let ensure
 host.io=(name,...args)=>{
  switch(name){
   case'id':return typeof args[0]==='string'?args[0]:args[0]?.id
   case'ready':return ready(args[0])
   case'revision':return revision()
   case'get':return library.get(args[0])
   case'patch':return library.patch(args[0],args[1],{ifCurrent:args[2]})
   case'file':{const latest=args[0];return new File([latest.content],latest.name||latest.title||'libro',{type:latest.mimeType||latest.content.type||''})}
   case'measure':return measureFile(args[0],{isActive:args[1]})
   case'complete':return hasComplete(args[0])?complete(args[0].wordCount):null
   case'fields':return {...args[0],wordCountContentRevision:args[1],lengthDirty:true}
   case'change':return onChange(...args)
   case'error':return onError(...args)
   case'ensure':return ensure(args[0])
   case'swallow':return args[0].catch(()=>{})
   case'task':{const context=args[0],entry=context.entry;let cancelled=entry.cancelled
    const guard=new core.RustLengthGuard(lifetime,cancelled)
    Object.defineProperty(entry,'nativeGuard',{value:guard})
    Object.defineProperty(entry,'cancelled',{configurable:true,enumerable:true,get:()=>cancelled,set:value=>{cancelled=value;guard.setCancelled(value)}})
    return host.tail.catch(()=>{}).then(()=>new Promise((resolve,reject)=>{
    const job={...context,resolve,reject};step(job,'job')
   })).catch(callback('job-error',context))}
   default:throw Error('Unknown length IO: '+name)
  }
 }
 for(const name of ['id','ready','revision','get','patch','file','measure','complete','fields','change','error','ensure','swallow','task'])host[name]=(...args)=>host.io(name,...args)
 ensure=book=>new Promise((resolve,reject)=>step({host,resolve,reject},'ensure',book))
 return {ensure,geometryState:book=>step({host},'geometry',book),cancel:id=>step({host},'cancel',id),
  retry(book){return step({host,receiver:this},'retry',book)},dispose:()=>step({host},'dispose')}
}
