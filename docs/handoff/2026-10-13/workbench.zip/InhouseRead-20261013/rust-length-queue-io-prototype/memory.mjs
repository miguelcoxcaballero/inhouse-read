import {createServer} from 'node:http'
import {readFile,writeFile} from 'node:fs/promises'
import {chromium} from 'file:///C:/Users/migue/Documents/InhouseRead-New/node_modules/playwright/index.mjs'
const server=createServer(async(req,res)=>{try{const name=req.url==='/'?'index.html':req.url.slice(1);if(!['index.html','factory.mjs','legacy.mjs','book-length.mjs','pkg/inhouse_read_ui.js','pkg/inhouse_read_ui_bg.wasm'].includes(name)){res.writeHead(404);return res.end()}if(name==='index.html'){res.setHeader('Content-Type','text/html');return res.end('<!doctype html><title>Length queue ownership</title>')}res.setHeader('Content-Type',name.endsWith('wasm')?'application/wasm':'text/javascript');res.end(await readFile(new URL(name,import.meta.url)))}catch(error){res.writeHead(500);res.end(String(error))}})
await new Promise(resolve=>server.listen(4522,'127.0.0.1',resolve));const browser=await chromium.launch({headless:true})
const batches=[]
try{
 const page=await browser.newPage();await page.goto('http://127.0.0.1:4522/');const cdp=await page.context().newCDPSession(page)
 await page.evaluate(async()=>{
  const ui=await import('./pkg/inhouse_read_ui.js');await ui.default();ui.length_queue_prepare()
  const {createNativeLengthQueue}=await import('./factory.mjs'),legacy=await import('./legacy.mjs'),length=await import('./book-length.mjs')
  const helpers={ready:legacy.isBookLengthReady,revision:legacy.newContentRevision,hasComplete:length.hasCompleteWordCount,complete:length.completeWordCount}
  window.lengthLifetime={ui,baseline:ui.ui_live_handles(),async batch(cancelled){
   for(let i=0;i<100;i++){
    const record={id:'book',name:'book.epub',contentRevision:'rev',content:new Blob(['book'])}
    const library={get:async()=>record,patch:async(id,fields,options)=>options.ifCurrent(record)?{...record,...fields}:null}
    let started=false,guard;const measureFile=async(file,{isActive})=>{guard=isActive;started=true;if(cancelled)return new Promise(()=>{});return length.completeWordCount(1000)}
    let queue=createNativeLengthQueue(library,{measureFile},ui,helpers),promise=queue.ensure(record)
    while(!started)await Promise.resolve()
    if(cancelled){queue.cancel('book');if(guard())throw Error('Cancelled guard still active')}
    else{const saved=await promise;if(saved.wordCount!==1000)throw Error('Result mismatch')}
    queue.dispose();if(guard())throw Error('Disposed guard still active');queue=null;promise=null;guard=null
   }
  }}
 })
 for(const cancelled of [false,true])for(let batch=0;batch<10;batch++){
  await page.evaluate(cancelled=>window.lengthLifetime.batch(cancelled),cancelled)
  await cdp.send('HeapProfiler.collectGarbage');await cdp.send('HeapProfiler.collectGarbage')
  const state=await page.evaluate(()=>({handles:window.lengthLifetime.ui.ui_live_handles(),baseline:window.lengthLifetime.baseline,scopes:window.lengthLifetime.ui.length_queue_scopes(),guards:window.lengthLifetime.ui.length_queue_guards()}))
  batches.push({cancelled,batch,...state});if(state.handles!==state.baseline||state.scopes!==0||state.guards!==0)throw Error('Ownership mismatch: '+JSON.stringify(state))
 }
 console.log(JSON.stringify({status:'passed',completed:1000,cancelled:1000,batches}))
}finally{await browser.close();await new Promise(resolve=>server.close(resolve));await writeFile(new URL('./memory.json',import.meta.url),JSON.stringify(batches,null,2))}
