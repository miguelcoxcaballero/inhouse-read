from pathlib import Path
out=Path(__file__).parent
s=(out/'benchmark.mjs').read_text(encoding='utf8').replace('4521','4524')
s=s.replace('  const results=[]','''  const db=await new Promise((resolve,reject)=>{const r=indexedDB.open('length-queue-benchmark',1);r.onupgradeneeded=()=>r.result.createObjectStore('books',{keyPath:'id'});r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error)});
  const read=id=>new Promise((resolve,reject)=>{const r=db.transaction('books').objectStore('books').get(id);r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error)});
  const patch=(id,fields,options)=>new Promise((resolve,reject)=>{const tx=db.transaction('books','readwrite'),store=tx.objectStore('books'),r=store.get(id);let saved=null;r.onsuccess=()=>{const current=r.result;if(options.ifCurrent(current)){saved={...current,...fields};store.put(saved)}};tx.oncomplete=()=>resolve(saved);tx.onerror=tx.onabort=()=>reject(tx.error)});
  const results=[]''')
s=s.replace('for(const checks of [0,20,1000])','for(const checks of [4000,20000])')
s=s.replace("Array.from({length:100}","Array.from({length:3}")
s=s.replace("content:new Blob(['book'])", "content:new Blob(['word '.repeat(checks)],{type:'text/plain'})")
start=s.index('    let count=0;const library=');end=s.index('    const queue=',start)
s=s[:start]+'''    await new Promise((resolve,reject)=>{const tx=db.transaction('books','readwrite'),store=tx.objectStore('books');store.clear();for(const record of records.values())store.put(record);tx.oncomplete=resolve;tx.onerror=()=>reject(tx.error)});
    let count=0;const library={get:read,patch};
    const options={measureFile:async(file,{isActive})=>{const words=await length.countTextWords(await file.text(),{language:'en',isActive});count++;return length.completeWordCount(words)}};
'''+s[end:]
s=s.replace('count!==100||values.some(value=>value.wordCount!==1000)','count!==3||values.some(value=>value.wordCount!==checks)')
s=s.replace('for(let i=0;i<4;i++)','for(let i=0;i<2;i++)')
s=s.replace('results.push({jobs:100,activeChecksPerJob:checks','results.push({jobs:3,wordsPerBook:checks')
s=s.replace("new URL('./benchmark.json'", "new URL('./benchmark-idb.json'")
s=s.replace("includes:'100 jobs, promise scheduling, file construction, guards and callbacks; fake storage, excludes parser and database IO'", "includes:'3 jobs with actual IndexedDB transactions and Blob/File bytes, Intl word counter with original yields and cancellation; excludes PDF/EPUB extraction, whole UI and actual phone'")
s=s.replace('console.log(JSON.stringify(results.map(({jobs,activeChecksPerJob,jsMedian,rustMedian})=>({jobs,activeChecksPerJob,jsMedian,rustMedian}))))','console.log(JSON.stringify(results))')
(out/'benchmark-idb.mjs').write_bytes(s.encode('utf8'))
