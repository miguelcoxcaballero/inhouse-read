param([Parameter(Mandatory=$true)][string]$Prototype,[string]$Label='build')
$env:RUSTUP_HOME='D:/InhouseRead-Rust/rustup'
$env:CARGO_HOME='D:/InhouseRead-Rust/cargo'
$env:CARGO_TARGET_DIR='D:/InhouseRead-Rust/ui-target'
$env:RUSTFLAGS='-C target-feature=+reference-types,-multivalue'
$env:CARGO_TARGET_X86_64_PC_WINDOWS_GNU_LINKER='D:/InhouseRead-Rust/rustup/toolchains/1.99.0-x86_64-pc-windows-gnu/lib/rustlib/x86_64-pc-windows-gnu/bin/rust-lld.exe'
$env:CARGO_TARGET_X86_64_PC_WINDOWS_GNU_RUSTFLAGS='-C linker-flavor=gnu-lld -C link-self-contained=yes'
& D:/InhouseRead-Rust/cargo/bin/cargo.exe +1.99.0-x86_64-pc-windows-gnu build --manifest-path (Join-Path $Prototype 'Cargo.toml') --locked --release --target wasm32-unknown-unknown > (Join-Path $Prototype ($Label+'.log')) 2>&1
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
& D:/InhouseRead-Rust/wasm-bindgen-0.2.105/wasm-bindgen-0.2.105-x86_64-pc-windows-msvc/wasm-bindgen.exe D:/InhouseRead-Rust/ui-target/wasm32-unknown-unknown/release/inhouse_read_ui.wasm --target web --remove-name-section --out-dir (Join-Path $Prototype 'pkg')
exit $LASTEXITCODE

