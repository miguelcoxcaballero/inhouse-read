import assert from 'node:assert/strict';
import {readFileSync,writeFileSync} from 'node:fs';
import * as ui from './pkg/inhouse_read_ui.js';
ui.initSync({module:readFileSync(new URL('./pkg/inhouse_read_ui_bg.wasm',import.meta.url))});
const baseline=ui.ui_live_handles(),snapshot={pixels:new Uint8Array(32)},entry={snapshot,key:{bookId:'book'}};
const cache=new ui.RustPreparedPageCache({entry},()=>{}),held=ui.ui_live_handles();
assert.ok(held>=baseline+2,{baseline,held});assert.equal(cache.peek(),snapshot);cache.free();assert.equal(ui.ui_live_handles(),baseline);
const failure=new Error('controlled constructor');
for(let i=0;i<1000;i++){
 assert.throws(()=>new ui.RustPreparedPageCache({get generation(){throw failure;}},()=>{}),e=>e===failure);
 assert.equal(ui.ui_live_handles(),baseline);
 const cycle={};cycle.self=cycle;
 assert.throws(()=>ui.prepared_page_mismatch({locator:cycle},{locator:null},false),TypeError);
 assert.equal(ui.ui_live_handles(),baseline);
}
const result={baseline,held,after:ui.ui_live_handles(),errors:2000,positiveControl:true};writeFileSync(new URL('lifetime-control.json',import.meta.url),JSON.stringify(result,null,2));console.log(JSON.stringify(result));
